<!DOCTYPE html PUBLIC "-//IETF//DTD HTML 2.0//EN">
<HTML>
<body style="background-color:#F0F0F0;">
   <HEAD>
      <TITLE>
         Simulation
      </TITLE>
   </HEAD>
<BODY>
<h1 style="text-align:center;">Between the Lines</h1>
<h1 style="text-align:center;">Simulation</h1>
<P style="text-align:center;"> Start the simulation.</P>

<div align="center">
	<input name="newThread" type="button" value="Begin" align="center" onclick="window.open('Drive.php', '_parent')"/>
</div>

</BODY>
</HTML>