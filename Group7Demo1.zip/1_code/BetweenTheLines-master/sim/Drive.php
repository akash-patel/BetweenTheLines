<HTML>
<title>Simulation: Driving...</title>
<div align="center">
	<h1> Customer drives into parking garage.</h1>
	<img src="Drive.gif" alt="some_text"><br>
	<input name="newThread" type="button" value="Continue" align="center" onclick="window.open('Second.php', '_parent')"/>
</div>
</HTML>
