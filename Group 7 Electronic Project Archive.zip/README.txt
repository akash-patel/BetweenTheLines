
Between The Lines

Software Engineering Group 7

This repository is for Software Engineering 332:452.

Demo 1 for this project was presented in the EIT Lab in the Engineering Building on April 1, 2014, 10:30 AM - 11:00 AM

Demo 2 for this project was presented in the EIT Lab in the Engineering Building on May 7, 2014, 2:00 PM - 2:30 PM

This repository contains all the files necessary to run the website.
This code can be hosted locally using a program like XAMPP to host an Apache and MySQL server.
The website is also hosted and can be accessed via http://whiteledge.com which is periodically updated, this was last updated in preparation for the second demo. A sample username is "john" and with password "doe123456"

Note: This website is optimized for HTML5. Users who are using browsers that do not incorporate HTML5 may find issues with certain features such as the date chooser. We recommend using Google Chrome when on the website for the best experience.

Installation Guide:

1) Install XAMPP
2) Copy all files from Demo 2\1_code\Website and place them in the htdocs directory for your XAMPP install
3) Import DatabaseTemplate.sql using PHPMyAdmin
