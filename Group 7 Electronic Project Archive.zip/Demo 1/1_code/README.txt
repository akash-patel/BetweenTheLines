BetweenTheLines
===============

Software Engineering Group 7

This repository is for Software Engineering 332:452.

Demo 1 for this project was presented in the EIT Lab in the Engineering Building on April 1, 2014, 10:30 AM - 11:00 AM

This repository contains all the files necessary to run the website.
This code can be hosted locally using a program like XAMPP to host an Apache and MySQL server.
The website is also hosted and can be accessed via http://whiteledge.com which is periodically updated.

Current features that have been implemented in the design include:

-Registration

-Reservation (Creating & Deleting)

-Elevator Simulation

-Parking Simulation

Notes:
You need to enter a username and password for the database in config.inc
You can easily unpack the database by importing from database.sql