  <!-- written by: Akash Patel, Jerry Wasdyke 
  tested by: Akash Patel, Jerry Wasdyke
  debugged by: Akash Patel, Jerry Wasdyke -->

<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Simulation | Welcome</title>
    <link rel="stylesheet" href="../css/foundation.css" />
    <script src="../js/vendor/modernizr.js"></script>
  </head>
<body style="background-color:#F0F0F0;">


<h1 style="text-align:center;">Between the Lines</h1>
<h1 style="text-align:center;">Simulation</h1>
<br>
<div class="panel">
<P style="text-align:center;"> Start the simulation.</P>

<div align="center">
	 <form method="POST" action="Drive.php"><input type="submit"class="button" value="Continue"></form>

</div>
</div>	

</BODY>

	    <script src="../js/vendor/jquery.js"></script>
    <script src="../js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
</HTML>