  <!-- written by: Akash Patel, Jerry Wasdyke 
  tested by: Akash Patel, Jerry Wasdyke
  debugged by: Akash Patel, Jerry Wasdyke -->

<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Simulation: Elevator</title>
    <link rel="stylesheet" href="../css/foundation.css" />
    <script src="../js/vendor/modernizr.js"></script>
  </head>
<body style="background-color:#F0F0F0;">
<title>Simulation: Elevator</title>
<div align="center">
	<h1> Customer drives up to elevator.</h1>
	<img src="elevator.jpg" alt="some_text"><br><br>
  <form method="POST" action="Third.php"><input type="submit"class="button" value="Continue"></form>
</div>
</body>
	    <script src="../js/vendor/jquery.js"></script>
    <script src="../js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
</HTML>
