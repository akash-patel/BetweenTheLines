<!DOCTYPE html>
<html>
	<body>
		<hr>
		<small>&copy; 2014 Between the Lines. All Rights Reserved.<br>
		Beware this is an educational site (done as a project for a software engineering course) and there are no actual services being offered. 
		Please do not enter any information in any of the forms that you are worried about being compromised.
		We are not responsible for any miscues that may result because of this.</small><br>
	</body>
</html>
