README
======

Pictures
-------
BetweenTheLines.gif
BTL.gif
BTLLogo.gif
fav.gif


Web files
-------
admin.php			- administrative controls for reservations
adminAdd.php			- adds reservations specified by admin
checkextendreservation.php	- checks if extending reservation is valid
deletereservation.php		- cancels a reservation by deletion
extendreservation.php		- extends an active reservation
footer.php			- displays html at bottom of page
functions.php			- contains some common functions
header.php			- displays website header as html
index.php			- the site's login page
loginproc.php			- validates user's identity 
logout.php			- ends the user's session
register.php			- page to create an account
registerproc.php		- creates a user account
reservation.php			- main page to create reservation
reservation2.php		- next steps for creating reservation
reservation3.php		- final step for creating reservation
securedpage.php			- the user's main portal
viewallreservations.php		- displays log of all of user's reservations

config.inc			- file used to connect to MySQL database
DatabaseTemplate.sql		- btl database file


CSS FOLDER 
IMG FOLDER
JS FOLDER

SIM FOLDER
-------
	Pictures
	-------
	Drive.gif	 - picture that appears in second.php
	exit.gif	 - picture that appears in final.php
	elevator.jpeg	 - picture that appears in third.php


	Web files
	--------
	adminProc.php	      	- php file that allows the floor to be manually changed in the photosensor page.
	drive.php             	- page shows a driver going up to the elevator
	exitelevator.php	- page containing the exit license plate scanner
	final.php		- page that calculates refund or extra payment and ends simulation
	fourth.php		- page shows the elevator which selects the first available floor
	index.php		- welcome page for the simulator
	LicenseExitProc.php	- php file that compares the inputted licneses and time to the database license and time
	LicenseProc.php		- php file that compares the inputted licenses to the database licenses
	photosensor.php		- page shows the photosensor simulation
	Second.php		- page shows a driver heading to the garage
	Third.php		- page shows the license plate scanner for entering the elevator
	updateoccupancy.php	- php file that uploads the available spots for each floor level on the photosensor page
