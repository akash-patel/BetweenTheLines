--
-- MySQL 5.5.36
-- Fri, 09 May 2014 18:48:50 +0000
--

CREATE TABLE `occupancy` (
   `psensorid` varchar(3),
   `istaken` int(1) default '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('101', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('102', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('103', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('104', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('105', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('106', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('107', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('108', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('109', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('201', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('202', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('203', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('204', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('205', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('206', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('207', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('208', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('209', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('301', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('302', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('303', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('304', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('305', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('306', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('307', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('308', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('309', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('401', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('402', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('403', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('404', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('405', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('406', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('407', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('408', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('409', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('501', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('502', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('503', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('504', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('505', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('506', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('507', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('508', '0');
INSERT INTO `occupancy` (`psensorid`, `istaken`) VALUES ('509', '0');

CREATE TABLE `reservations` (
   `username` varchar(255),
   `reservationid` int(10),
   `licenseplate` varchar(10),
   `state` varchar(20),
   `startdatetime` datetime,
   `enddatetime` datetime,
   `startdatetimesec` int(10),
   `enddatetimesec` int(10),
   `cc` varchar(16),
   `cvv` int(4),
   `ccexpdate` date,
   `completed` int(1) default '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `users` (
   `username` varchar(255),
   `password` varchar(255),
   `firstname` varchar(255),
   `lastname` varchar(255),
   `email` varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`username`, `password`, `firstname`, `lastname`, `email`) VALUES ('john', '20ffbf4ac7ba4ff1775f67f043a38bab', 'John', 'Doe', 'john@doe.com');