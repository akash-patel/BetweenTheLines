/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

Files under BetweenTheLines/src/com/example/betweenthelines
Login.java
	This file handles the first page that the user sees, which is the login.
	Within this page the user is able to reset password, or register with a click of a button.
Registration.java
	This files handles user registration. Customers are asked to input their First Name, Last Name, Email, Username and Password.
	If the user already exists then an error message will show 
	If the user doesnt exists then the registration will be complete and a confirmation page will open.
 Registered.java
 	This file contains the confirmations page.
 	The user will be displayed the First Namd and Last Name used to register. Also their email and their username.
 Main.java
 	Within this file the user has the option to change password or go to the main page for reservations.
 ChangePassword.java
 	Within this file the user is allowef to change their password.
 	If they input the same password that they currently have, they will receive an error message.
 Reservation.java
 	Within this page the user has the ability to select to view their reservations according to their reservation id's.
 	The user is also allowed to create a reservation with a click of a button.
 CreateReservation.java
 	Within this file customers create reservation with their start time and date and the time and date they want to end.
 	This file also verifies the date inputted by the user.
 	They are also required to enter the type of vehicle they have.
 	Their license plate number, the state of their license plate, their credit card number, security code, and the expiration date of their credit card.
 	This file also verifies if the credit card enter was valid.
ViewReservation.java
	Within this file it displays the list of reservations according to the customers Reservations ID's

Files under BetweenTheLines/src/com/example/betweenthelines/library
DatabaseHandler.java
	Within this file is the functions that manages the SQLite database.
	SQLite database is only used to save users information either when login happens or registration.
	When the user logs out, the information that was saved within the SQLite datebase of the particular user is deleted.
JSONParser.java
	Within this file HTTP calls are being handled. Which is responsible of making a HTTP call and getting the response.
	For example when the user logins, a request is sent with their information in a form of a GET/POST method. Once the users information is verified, a response is generated in JSON format.
UserFunctions.java
	Within this file the users information is formatted in a way that can be sent by the JSONParser.


In order to first run the app you must make sure that yoou have the proper program to support this type of file.
If you go to http://developer.android.com/sdk/index.html?hl=sk
	Download the ADT Bundle for Windows	

How to run the app using the Android SDK emulator:
First open the Android Virtual Device Manager
Click on create new AVD
	ACD Name: AVD_for_Nexus_5_by_Google
	Device: Nexus 5(4.95", 1080 X 1920: xxhdpi)
	Target: Android 4.4.2 - API Level 19
	Keyboard: Hardware keyboard present
	Skin: HVGA
	Memory Options:
		RAM: 2048 
		VM Heap: 64
	Internal Storage: 200 MiB
	SD Card: 100 MiB
	Emulation Options:
		Use Host GPU

After the AVD is created then run it.
Import file into Android SDK
	Go to File tab and select Import
	Select Android Folder and select Existing Android Code Into Workspace. 
	Then Browse for where the file is located after extraction.
	Import the file BetweenTheLines.

Make sure the AVD is connected and then just run the program.

Features included:
Registration
	Checks for valid email address
	Username must be longer than 5 characters
	Checks if the username already exists within the database.
Login
	Verifies that the username and password matches the one found in the database.
	If valid then it will direct the user to the main page.
Forgot Password
	If by any change the user forgot their password, they will receive a random made string to their email in order to login. When they login they are required to change their password.
Main Page
	Within the main page there are two options, either to change password or to the main page of their reservations.
Reservation
	Within this page you can check a list of reservations made.
	You can also cancel a reservation by inputting their reservation id.
	You can also go to the page that can let the user create a reservation.

	
