/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

package com.example.betweenthelines;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.library.DatabaseHandler;
import com.example.library.MyOnItemSelectedListener;
import com.example.library.UserFunctions;

public class CreateReservation extends ActionBarActivity {
	
	Dialog picker;
	Button select, set, otherselect, nextbtn;
	
	TimePicker timep;
	DatePicker datep;
	
	Integer shour,sminute,smonth,sday,syear;
	Integer sTimesec;
	Integer ehour,eminute,emonth,eday,eyear;
	Integer eTimesec;
	
	TextView time, date;
	TextView othertime, otherdate;
	TextView error, error2;
	
	Spinner spinnerCR, monthCredit, yearCredit, spinnerState;
	
	EditText LicensePlate, CreditCard, CodeCVV;
	
	String expirdate;
	
	
	
	/**
	 *  Called when the activity is first created.
     *  JSON Response node names.
     **/
    private static String KEY_SUCCESS = "success";
    private static String KEY_USERNAME = "uname";
    private static String KEY_RESERVATIONID = "reservationid";
    private static String KEY_LICENSEPLATE = "license";
    private static String KEY_STARTDATETIMESEC = "startdatetimesec";
    private static String KEY_ENDDATETIMESEC = "enddatetimesec";
    private static String KEY_STARTDATETIME = "startdatetime";
    private static String KEY_ENDDATETIME = "enddatetime";
    private static String KEY_CC = "credit";


	
	// Variable for storing current date and time
	private int mHour, mMinute;
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.create_reservation);
		
		
		Log.d("CreateReservations","HI IM ENTERING ON CREATE FOR CREATE RESERVATION LINE90");
		
		
		LicensePlate = (EditText)findViewById(R.id.License);
		CodeCVV = (EditText)findViewById(R.id.CVVcode);
		CreditCard = (EditText)findViewById(R.id.creditCard);

		select = (Button)findViewById(R.id.btnSelect);
		otherselect = (Button)findViewById(R.id.otherbtnSelect);
		nextbtn = (Button) findViewById(R.id.okey);
		
	    time = (TextView)findViewById(R.id.textTime);
	    date = (TextView)findViewById(R.id.textDate);
	    othertime = (TextView)findViewById(R.id.othertextTime);
	    otherdate = (TextView)findViewById(R.id.othertextDate);	    
	    error = (TextView)findViewById(R.id.reserveErrorMsg);
	    error2 = (TextView)findViewById(R.id.creditErrorMsg);
	    
	    spinnerCR = (Spinner) findViewById(R.id.crspinner);
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Vehicle_Size, R.layout.spinner_layout);		
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerCR.setAdapter(adapter);	
		spinnerCR.setOnItemSelectedListener(new MyOnItemSelectedListener());
		
	    spinnerState = (Spinner) findViewById(R.id.ecspinner);
		ArrayAdapter<CharSequence> stateadapter = ArrayAdapter.createFromResource(this, R.array.state_arrays, R.layout.spinner_layout);		
		stateadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerState.setAdapter(stateadapter);	
		spinnerState.setOnItemSelectedListener(new MyOnItemSelectedListener());
		
		//The spinner for the month of credit card
		monthCredit = (Spinner)findViewById(R.id.mmspinner);
		ArrayAdapter<CharSequence> adaptermm = ArrayAdapter.createFromResource(this, R.array.Months, R.layout.spinner_layout);
		adaptermm.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		monthCredit.setAdapter(adaptermm);
		monthCredit.setOnItemSelectedListener(new MyOnItemSelectedListener());
		
		//The spinner for the year of credit card
		yearCredit = (Spinner)findViewById(R.id.yyspinner);
		ArrayAdapter<CharSequence> adapteryy = ArrayAdapter.createFromResource(this, R.array.Year, R.layout.spinner_layout);
		adapteryy.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		yearCredit.setAdapter(adapteryy);
		yearCredit.setOnItemSelectedListener(new MyOnItemSelectedListener());
		
		

		
		
         
		
		
	    select.setOnClickListener(new View.OnClickListener() {
	      @Override
	      public void onClick(View view) {
	        // TODO Auto-generated method stub
	    	  
	        picker = new Dialog(CreateReservation.this);
	        picker.setContentView(R.layout.fragment_create_reservation);
	        picker.setTitle("Select Date and Time");
	        datep = (DatePicker)picker.findViewById(R.id.datePicker);
	        timep = (TimePicker)picker.findViewById(R.id.timePicker1);
	        set = (Button)picker.findViewById(R.id.btnSet);
	        
	        set.setOnClickListener(new View.OnClickListener() {
	          @Override
	          public void onClick(View view) {
	            // TODO Auto-generated method stub

	        	  
					// Process to get Current Time
					final Calendar c2 = Calendar.getInstance();
					mHour = c2.get(Calendar.HOUR_OF_DAY);
					mMinute = c2.get(Calendar.MINUTE);
		  			
					
		        	  
		        	//Returns selected month
		            smonth = datep.getMonth();
		            //Returns selected day of month
		            sday = datep.getDayOfMonth();
		            //Returns selected year
		            syear = datep.getYear();
		            
		            //return current hour
		            shour = timep.getCurrentHour();
		            //returns current minute
		            sminute = timep.getCurrentMinute();

		            //THIS GETS THE SELECTED TIME IN SEC
		            sTimesec = (shour*3600)+(sminute*60);
		           		            
		            
		            //IF THE CURRENT TIME IS GREATER THAN SELECTED TIME IT WILL RETURN AN ERROR
		            if(mHour >= shour && mMinute >= sminute){
			        	error.setText("Error: Start time for reservation must be in the future.");
			        	picker.dismiss();
			        }
		            else
		            {
			            time.setText("Start Time: "+shour+ ":" +sminute);
			            date.setText("Start Date: "+(smonth+1)+"/"+sday+"/"+syear);
			            error.setText("");
			            picker.dismiss();
		            }
		            
		          }
		        });
		        picker.show();
	      }
	    });
	    
	    
	    
	    
	    otherselect.setOnClickListener(new View.OnClickListener() {
		      @Override
		      public void onClick(View view) {
		        // TODO Auto-generated method stub
		        picker = new Dialog(CreateReservation.this);
		        picker.setContentView(R.layout.fragment_create_reservation);
		        picker.setTitle("Select Date and Time");
		        datep = (DatePicker)picker.findViewById(R.id.datePicker);
		        timep = (TimePicker)picker.findViewById(R.id.timePicker1);
		        set = (Button)picker.findViewById(R.id.btnSet);
		        
		        set.setOnClickListener(new View.OnClickListener() {
		          @Override
		          public void onClick(View view) {
		            // TODO Auto-generated method stub
		        	   
					// Process to get Current Time
					final Calendar c2 = Calendar.getInstance();
					mHour = c2.get(Calendar.HOUR_OF_DAY);
					mMinute = c2.get(Calendar.MINUTE);
		  			
		        	  
		        	//Returns selected month
		            emonth = datep.getMonth();
		            //Returns selected day of month
		            eday = datep.getDayOfMonth();
		            //Returns selected year
		            eyear = datep.getYear();
		            
		            //return THE SELECTED HOUR AND MINUTE
		            ehour = timep.getCurrentHour();
		            eminute = timep.getCurrentMinute();
		            
		            
		            //THIS GETS THE SELECTED TIME IN SEC
		            eTimesec = (ehour*3600)+(eminute*60);
		            
		            
		            //IF THE CURRENT TIME IS GREATER THAN SELECTED TIME IT WILL RETURN AN ERROR
		            if(mHour >= ehour && mMinute >= eminute){
			        	error.setText("Error: End time or date for reservation must be in the future.");
			        	picker.dismiss();
			        }
		            //CHECKS IF THE END TIME IS GREATER THAN START TIME AND IF THEY ARE 15 MIN APART
		            else if((eTimesec < sTimesec) || ((eTimesec-sTimesec)<900))
		            {
		            	error.setText("Error: Invalid input Time");
		            	picker.dismiss();
		            }
		            else
		            {
			            othertime.setText("End Time: "+ehour+ ":" +eminute);
			            otherdate.setText("End Date: "+(emonth+1)+"/"+eday+"/"+eyear);
			            error.setText("");
			            picker.dismiss();
		            }
		            
		          }
		        });
		        picker.show();
		      }
		    });
	    
	    
	    
	    
	    nextbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

            	//If all attributes were inputted then redirect to function NetAsync
				Verifies();

                if (  ( !time.getText().toString().equals("")) && ( !date.getText().toString().equals("")) && ( !othertime.getText().toString().equals("")) && ( !otherdate.getText().toString().equals(""))
                		&& (!CreditCard.getText().toString().equals("")) && (!CodeCVV.getText().toString().equals(""))
                		&& (!LicensePlate.getText().toString().equals("")))
                {
                	
                	
                	Log.d("CreateReservation","IM ENTERING NETSYNC");
                	
                	
                	NetAsync(view);
                
                }
                //If only the Username was inputted, then display an error message
                else
                {
                    Toast.makeText(getApplicationContext(),
                            "Please input every field", Toast.LENGTH_SHORT).show();
                }
            }
	    });
        
	}
	
	
	public void Verifies(){
		
		String mmonth, yyear, dday;
		String errors = "";
		String credit;
		String curexpirdate;
		
		
		credit = CreditCard.getText().toString();

		
		if ((is_valid_luhn(credit) == false) || (credit.length() != 16)){
			errors += "You have entered an invalid credit card number.\n";
			CreditCard.setText("");
		}
		

		
		Log.d("CreatReservation", credit);
		Log.d("CreateReservation",""+credit.length());
		
		
		

        
        if(!CreditCard.getText().toString().equals(""))
        {
        	if(cc_type(CreditCard.getText().toString()) == "0")
        	{ 
        		errors += "You have entered a credit card number from a provider which is not accepted. Please use Visa, Mastercard, Discover, or American Express. Thank you.\n";
				CreditCard.setText("");      		
        	}

		}
			
        	//THIS GET THE CURRENT MONTH, YEAR, AND DAY
			final Calendar c2 = Calendar.getInstance();
			int month = c2.get(Calendar.MONTH);
			int year = c2.get(Calendar.YEAR);
			int day = c2.get(Calendar.DAY_OF_MONTH);
			
			if(month < 10){
				mmonth = "0"+month;
			}else{
				mmonth = ""+month;
			}
			
			if(day < 10){
				dday = "0"+day;
			}else{
				dday = ""+day;
			}
			
			yyear = ""+year;
			
			
			curexpirdate = yyear + "-" + mmonth + "-" + dday;
			
			
			String selectmonth = String.valueOf(monthCredit.getSelectedItem());
			String selectyear = String.valueOf(yearCredit.getSelectedItem());
			
			expirdate = "20"+selectyear + "-" + selectmonth + "-31";
			
			
			Log.d("CreateReservation current date",expirdate);
			Log.d("CreateReservation expiration date",curexpirdate);
			
			
			
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			try{
				Date date = formatter.parse(expirdate);
				Date date2 = formatter.parse(curexpirdate);
				
				if(date.compareTo(date2) < 0){
					errors += "Your credit card is expired!\n";
					CreditCard.setText("");
				}
			}catch(ParseException e){
				e.printStackTrace();
			}

		error2.setText(errors);
	
	}

	
	
	
	/**
     * Async Task to check whether internet connection is working.
     **/
    //This class allows to perform background operations 
    //and publish results on the UI thread without having 
    //to manipulate threads and/or handlers
    private class NetCheck extends AsyncTask<String,String,Boolean>
    {
        private ProgressDialog nDialog;

        @Override
        //This is before it executes
        protected void onPreExecute(){
        	
        	
        	
        	Log.d("createReservation","IM HERE IN NETCHECK");
        	
        	
            super.onPreExecute();
            nDialog = new ProgressDialog(CreateReservation.this);
            nDialog.setTitle("Checking Network");
            nDialog.setMessage("Loading..");
            nDialog.setIndeterminate(false);
            nDialog.setCancelable(true);
            nDialog.show();
        }
        
        /**
         * Gets current device state and checks for working internet connection by trying Google.
        **/
        //This is a thread that runs in the background
        @Override
        protected Boolean doInBackground(String... args){

        	
        	
        	
        	Log.d("CreateReservation","NOW IM IN DOINBACKGROUND");
        	
        	
        	
        	//The following snippet shows how to use the ConnectivityManager to query the active 
        	//network and determine if it has Internet connectivity.
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            
            
            
            
            Log.d("createReservation","NOW IM CHECKING FOR NETWORK, DID IT WORK?");
            
            
            
            
            if (netInfo != null && netInfo.isConnected()) {
                try {
                    URL url = new URL("http://www.google.com");
                    HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
                    urlc.setConnectTimeout(3000);
                    urlc.connect();
                    if (urlc.getResponseCode() == 200) {
                        return true;
                    }
                } 
                catch (MalformedURLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } 
                catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            return false;

        }
        //This is done afterward the doInBackground.
        //The concrete type bound to result is the type of 
        //the return value from doInBackground, and thus 
        //the type of the parameter to onPostExecute.
        @Override
        protected void onPostExecute(Boolean th){
            if(th == true){
                //If the return value from doInBackground is true
            	//then ProcessLogin.execute() is activated.
            	
            	
            	
            	Log.d("createReservation","YES I GOT NETWORK!!!");
            	
            	
            	
            	
            	
            	nDialog.dismiss();
               // new ProcessReservation().execute();

            }
            else{
            	//Otherwise an error message is sent
            	
            	
            	Log.d("createReservation","DAMN IT I DONT HAVE NETWORK!!");
            	
            	
            	
            	
                nDialog.dismiss();
                error.setText("Error in Network Connection");
            }
        }
    }
	
    
    
    
	
    /**
     * Async Task to get and send data to My Sql database through JSON respone.
     **/
    //If everything goes well in doInBackground then this function is called.
    private class ProcessReservation extends AsyncTask<String, String, JSONObject> {
    	
    	private ProgressDialog pDialog;
    	
    	
    	//HH:MM:SS	
    	String youuser;
    	String hours, minutes, houre, minutee;
    	String startTime;
    	String endTime;
    	String startmonth, startday, startyear;
    	String endmonth, endday, endyear;  
    	String license;
    	String state;
    	String credit;
    	String code;
    	String endDate;
    	String startDate;
    	
    	
    	
        @Override
        //Before executing, initialize variables
        protected void onPreExecute() {
            super.onPreExecute();

            license = LicensePlate.getText().toString();
            state = String.valueOf(spinnerState.getSelectedItem());
            credit = CreditCard.getText().toString();
            code = CodeCVV.getText().toString();
            
           DatabaseHandler db = new DatabaseHandler(getApplicationContext());
           HashMap<String,String> user = new HashMap<String, String>(); 
   
            user = db.getUserDetails();  
            youuser = user.get("uname");

            
            
            if(shour < 10)
        	{
        		hours = "0"+shour;
        	}
            else
            	hours = ""+shour;
            
            if(sminute < 10)
            {
            	minutes = "0"+sminute;
            }
            else
            	minutes = ""+sminute;
            
            startTime = hours+":"+ minutes + ":00";
            
            if(ehour < 10)
        	{
        		houre = "0"+ ehour;
        	}
            else
            	houre = ""+ehour;
            
            if(eminute < 10)
            {
            	minutee = "0"+eminute;
            }
            else
            	minutee = ""+eminute;
            
            endTime = houre+ ":"+ minutee + ":00";
            
            smonth = smonth+1;
            if((smonth) < 10){
            	startmonth = "0"+smonth;
            }else
            	startmonth = ""+smonth;
            
            
            if(sday < 10){
            	startday = "0"+sday;
            }else{
            	startday = ""+sday;
            }

            
            startyear = ""+syear;
            endyear = ""+eyear;
            emonth=emonth+1;
            if((emonth) < 10){
            	endmonth = "0"+emonth;
            }else
            	endmonth = ""+emonth;
            
            if(eday < 10){
            	endday = "0"+eday;
            }else{
            	endday = ""+eday;
            }
            
            startDate = startyear+"-"+startmonth+"-"+startday;
            endDate = endyear+"-"+endmonth+"-"+endday;
            
            Log.d("CreateReservation",youuser);          
            Log.d("StartDate",startDate);
            Log.d("EndDate",endDate);
            Log.d("StartTime", startTime);
            Log.d("EndTime",endTime);

            
            
            
            Log.d("createReservation","WELL SINCE I HAVE NETWORK IM IN ONPREEXECUTE");   
            
            
            
            pDialog = new ProgressDialog(CreateReservation.this);
            pDialog.setTitle("Contacting Servers");
            pDialog.setMessage("Logging in ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }
        
        //In the background access the Database using JSONObject
        @Override
        protected JSONObject doInBackground(String... args) {
        	//Create an object to UserFunctions in order to access loginUser function
        	//which is located within UserFunctions.java
        	
        	
        	
        	Log.d("createReservation","IM HERE IN JSONOBJECT");
        	
        	
        	
            UserFunctions userFunction = new UserFunctions();
            /* When calling loginUser, the username and password are sent as parameters.
             * The JSON response is sent back from loginUser() function.
             */
            Log.d("createReservation","THIS IS BEFORE GOING TO JSON, WILL IT WORK?");
            Log.d("Create Reservation", expirdate);
            Log.d("Create Reservation", license);
            Log.d("Create Reservation", state);
            Log.d("Create Resevation",credit);
            Log.d("Create Reservation", code);
            
            JSONObject json = userFunction.reserveUser(startDate, startTime, endDate, endTime, youuser, license, state, credit, code, expirdate);
            
            return json;
        }

        @Override
        protected void onPostExecute(JSONObject json) {
            try {
               if (json.getString(KEY_SUCCESS) != null) {
            	   
            	   
            	   
            	   
            	   Log.d("createReservation","YES IT WORKED!!!");
            	   
            	   
            	   
            	   
                    String res = json.getString(KEY_SUCCESS);
                    
            
                    
                    
                    
                    
                    Log.d("CreateReservation", "WHERE IS THE PROBLEM?");
                    
                    
                    
                    if(Integer.parseInt(res) == 1){
                    	
                    	
                    	
                    	Log.d("CreateReservation","COULD IT BE HERE?");
                    	
                    	
                    	
                        pDialog.setMessage("Loading User Space");
                        pDialog.setTitle("Getting Data");
                        //Creates an object to DatabaseHandler
                        
                        
                        
                        
                        Log.d("CreateReservation","IM IN LINE 613?");
                        
                        
                        
                        
                        
                        DatabaseHandler db = new DatabaseHandler(getApplicationContext());
                        
                        
                        Log.d("CreateReservation","IM IN LINE 616?");
                        
                        
                        
                        JSONObject json_user = json.getJSONObject("reserve");						
                        
                        /**
                         * Clear all previous data in SQlite database.
                         **/
                        //Create an object to UserFunctions in order to access logoutUser function
                    	//which is located within UserFunctions.java
                        
                        
                        
                        
                        //UserFunctions logout = new UserFunctions();
                        Log.d("CreateReservation","HI IM IN LINE 719");
                        
                        
                        
                        //logout.logoutUser(getApplicationContext());
                        //This calls a function within DatabaseHandler.java, inorder to add a nee user
                        db.addReservation(json_user.getString(KEY_USERNAME),json_user.getString(KEY_RESERVATIONID),json_user.getString(KEY_LICENSEPLATE), json_user.getString(KEY_STARTDATETIME),json_user.getString(KEY_ENDDATETIME),json_user.getString(KEY_STARTDATETIMESEC),json_user.getString(KEY_ENDDATETIMESEC),json_user.getString(KEY_CC));
                        
                        /**
                        *If JSON array details are stored in SQlite it launches the User Panel.
                        **/
                        //After the login was verified, the app will go to activity called Main.java
                        //Which is the main page for the users account
                        Intent upanel = new Intent(getApplicationContext(), Reservation.class);
                        upanel.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        pDialog.dismiss();
                        startActivity(upanel);									
                        
                        /**
                         * Close Login Screen
                         **/
                         finish();
                    }
                    else{
                    	
                    	
                    	
                    	Log.d("createReservation","CRAP WHAT HAPPENED?");
                    	
                    	
                    	
                        pDialog.dismiss();
                        error.setText("Network Error");
                    }
                }
            } 
            catch (JSONException e) {
            	
            	
            	
            	Log.d("createReservation","CRAP WHAT HAPPENED?!!!");
            	
            	
            	
                e.printStackTrace();
            }
        }
    
    } 
    
    
	public boolean is_valid_luhn(String creditc) {
		final int[][] sumTable = {{0,1,2,3,4,5,6,7,8,9},{0,2,4,6,8,1,3,5,7,9}};
	    int sum = 0, flip = 0;
	    
	    for (int i = creditc.length() - 1; i >= 0; i--) {
	    	sum += sumTable[flip++ & 0x1][Character.digit(creditc.charAt(i), 10)];
	    }
	    
	    
	    
	    Log.d("IS_VALID_LUHN",""+sum%10);
	    
	    
	    
	    return sum % 10 == 0;
	}
    
    
	
	
	
	public String cc_type(String cc){
		String c = cc.substring(0, 1);
		
		
    	Log.d("CC_TYPE", c);

    	
    	
    	
		if (c.equals("4"))
			return "Visa ";
		else if (c.equals("5"))
			return "Mastercard ";	
		else if (c.equals("6"))
			return "Discover ";
		else if (c.equals("3"))
			return "American Express ";
		else
			return "0";

	}
	
	
    
    
  
    private void NetAsync(View v) {
    	Log.d("CreateReservation","IM IN NETASYNC NOW GOING TO NETCHECK");
		new NetCheck().execute();
	} 
	
}


