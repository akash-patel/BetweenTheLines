//This is a library file used to perform SQLite database operations.
/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

package com.example.library;

import java.util.HashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHandler extends SQLiteOpenHelper {

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 2;

    // Database Name
    private static final String DATABASE_NAME = "cloud_contacts";

    // Login table name
    private static final String TABLE_LOGIN = "login";
    // Login Table Columns names
    private static final String KEY_FIRSTNAME = "fname";
    private static final String KEY_LASTNAME = "lname";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_USERNAME = "uname";

    //Reservation table name
    private static final String TABLE_RESERVATION = "reservation";
    //Reservation table column names
    private static final String KEY_LICENSEPLATE = "license";
    private static final String KEY_STARTDATETIME = "startdatetime";
    private static final String KEY_ENDDATETIME = "enddatetime";
    private static final String KEY_STARTDATETIMESEC = "startdatetimesec";
    private static final String KEY_ENDDATETIMESEC = "enddatetimesec";
    private static final String KEY_CC = "credit";
    private static final String KEY_RESERVATIONID = "reservationid";

    

    //private DatabaseHandler dbHelper;
    private String[] allColumns = { DatabaseHandler.KEY_USERNAME,
        DatabaseHandler.KEY_RESERVATIONID,DatabaseHandler.KEY_LICENSEPLATE,
        DatabaseHandler.KEY_STARTDATETIME,DatabaseHandler.KEY_ENDDATETIME, DatabaseHandler.KEY_STARTDATETIMESEC,
        DatabaseHandler.KEY_ENDDATETIMESEC,DatabaseHandler.KEY_CC};

    
    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_LOGIN_TABLE = "CREATE TABLE " + TABLE_LOGIN + "("
                + KEY_USERNAME + " TEXT,"
                + KEY_FIRSTNAME + " TEXT,"
                + KEY_LASTNAME + " TEXT,"
                + KEY_EMAIL + " TEXT" + ")";
        db.execSQL(CREATE_LOGIN_TABLE);
        
        String CREATE_RESERVATION_TABLE = "CREATE TABLE " + TABLE_RESERVATION + "("
        		+ KEY_USERNAME + " TEXT,"
        		+ KEY_RESERVATIONID + " TEXT,"
        		+ KEY_LICENSEPLATE + " TEXT,"
        		+ KEY_STARTDATETIME + " TEXT,"
        		+ KEY_ENDDATETIME + " TEXT,"
        		+ KEY_STARTDATETIMESEC + " TEXT,"
        		+ KEY_ENDDATETIMESEC + " TEXT,"
        		+ KEY_CC + " TEXT" + ")";
        db.execSQL(CREATE_RESERVATION_TABLE);
    }

    
    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGIN);
        //db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATION);
        // Create tables again
        onCreate(db);
    }

    /**
     * Storing user details in database
     * */
    public void addUser(String uname, String fname, String lname, String email) {
        SQLiteDatabase db = this.getWritableDatabase();

        
        Log.d("Database", "HI IM IN ADDUSER IN DATABASE LINE102");
        Log.d("Database",uname);
        Log.d("Database",fname);
        Log.d("Database",lname);
        Log.d("Database",email);

        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, uname); // UserName
        values.put(KEY_FIRSTNAME, fname); // FirstName
        values.put(KEY_LASTNAME, lname); // LastName
        values.put(KEY_EMAIL, email); // Email

        // Inserting Row
        db.insert(TABLE_LOGIN, null, values);
        
        
        Log.d("Database", "BYE IM LEAVING ADDUSER LINE115");
        
        
        db.close(); // Closing database connection
    }


    /**
     * Storing user reservation
     **/
    public void addReservation(String username, String id, String licenseplate, String startdatetime,String enddatetime,String startdatetimesec,String enddatetimesec,String cc) {
    	SQLiteDatabase db = this.getWritableDatabase();
    	
    	Log.d("Database", "LINE 126");
    	
    	
    	ContentValues values = new ContentValues();
    	values.put(KEY_USERNAME, username);
    	values.put(KEY_RESERVATIONID, id);
    	values.put(KEY_LICENSEPLATE, licenseplate);
    	values.put(KEY_STARTDATETIME, startdatetime);
    	values.put(KEY_ENDDATETIME, enddatetime);
    	values.put(KEY_STARTDATETIMESEC, startdatetimesec);
    	values.put(KEY_ENDDATETIMESEC, enddatetimesec);
    	values.put(KEY_CC, cc);

    	//Inserting Row
    	db.insert(TABLE_RESERVATION, null, values);
    	
    	Log.d("Database", "LINE 126");
    	
    	
    	db.close();
    }
    
    /**
     * Getting user data from database
     * */
    public HashMap<String, String> getUserDetails(){
    	
    	
    	
    	
    	Log.d("Database func","LINE 154");
    	
    	
    	
        HashMap<String,String> user = new HashMap<String,String>();
        String selectQuery = "SELECT  * FROM " + TABLE_LOGIN;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        

        
        
        // Move to first row
        cursor.moveToFirst();
        if(cursor.getCount() > 0){
            user.put("fname", cursor.getString(1));
            user.put("lname", cursor.getString(2));
            user.put("email", cursor.getString(3));
            user.put("uname", cursor.getString(0));
        }
        cursor.close();
        db.close();
        // return user
        
        
        
        
        Log.d("Database func","LINE 180");
        
        
        
        
        return user;
    }
    
    public HashMap<String, String> getReserveDatails(){
    	
    	
    	Log.d("Database func","LINE 193");
    	
    	
    	
    	HashMap<String, String> reserve = new HashMap<String, String>();
    	String selectQuery = "SELECT * FROM " + TABLE_RESERVATION;
    	
    	SQLiteDatabase db = this.getReadableDatabase();
    	
    	Cursor cursor = db.rawQuery(selectQuery,null);
    	cursor.moveToFirst();
    	if(cursor.getCount() > 0){
    		reserve.put("uname", cursor.getString(0));
            reserve.put("reservationid", cursor.getString(1));
            reserve.put("license", cursor.getString(2));
            reserve.put("startdatetime", cursor.getString(3));
            reserve.put("enddatetime", cursor.getString(4));
            reserve.put("startdatetimesec", cursor.getString(5));
            reserve.put("enddatetimesec", cursor.getString(6));
            reserve.put("credit", cursor.getString(7));

    	}
    	cursor.close();
    	db.close();
    	
    	return reserve;
    }


    /**
     * Getting user login status
     * return true if rows are there in table
     * */
    public int getRowCount() {
        String countQuery = "SELECT  * FROM " + TABLE_LOGIN;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int rowCount = cursor.getCount();
        db.close();
        cursor.close();

        // return row count
        return rowCount;
    }

    
    /**
     * Getting user login status
     * return true if rows are there in table
     * */
    public int getRowCountReserve(String username) {
      // String countQuery = "SELECT  * FROM " + TABLE_RESERVATION;
        
        //String countQuery = "SELECT KEY_USERNAME FROM " + TABLE_RESERVATION + "WHERE" +;
        SQLiteDatabase db = this.getReadableDatabase();
        /* Cursor cursor = db.rawQuery(countQuery, null);
        int rowCount = cursor.getCount();
        db.close();
        cursor.close();*/
      // return row count

        // return row count
    	String userCol [] = {allColumns[0]};
    	Cursor c = db.query(TABLE_RESERVATION, userCol,allColumns[0]+"='"+username+"'", null,null,null,null);
    	int rowCount = c.getCount();
        db.close();
        
    	return rowCount;
    }
  
    
    

    /**
     * Re crate database
     * Delete all tables and create them again
     * */
    public void resetTables(){
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete All Rows
        db.delete(TABLE_LOGIN, null, null);
        db.close();
    }

}
