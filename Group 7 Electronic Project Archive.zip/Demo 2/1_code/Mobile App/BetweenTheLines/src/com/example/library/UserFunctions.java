/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

package com.example.library;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;


public class UserFunctions {

    private JSONParser jsonParser;

    
    //URL of the PHP API
    private static String loginURL = "http://10.0.2.2/btl_login_api/";
    private static String registerURL = "http://10.0.2.2/btl_login_api/";
    private static String forpassURL = "http://10.0.2.2/btl_login_api/";
    private static String chgpassURL = "http://10.0.2.2/btl_login_api/";
    
    private static String reservationURL = "http://10.0.2.2/btl_login_api/";
    private static String deleteURL = "http://10.0.2.2/btl_login_api/"; 
    private static String getReservationsURL = "http://10.0.2.2/btl_login_api/"; 

    private static String login_tag = "login";
    private static String register_tag = "register";
    private static String forpass_tag = "forpass";
    private static String chgpass_tag = "chgpass";
    private static String getReservations_tag = "display";
    
    private static String reservation_tag = "reservation";
    private static String delete_tag = "delete";

    // constructor
    public UserFunctions(){
    	//Creates a new object to JSONParser.java
        jsonParser = new JSONParser();
    }

    
    
    
    /**
     * Function to Login
     **/

    public JSONObject loginUser(String username, String password){
        // Building Parameters
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", login_tag));
        params.add(new BasicNameValuePair("username", username));
        params.add(new BasicNameValuePair("password", password));
        //Uses JSONParser object created in the contructor inorder to access
        //the function getJSONFromUrl
        JSONObject json = jsonParser.getJSONFromUrl(loginURL,"POST", params);
        return json;
    }

    
    
    
    
    public JSONObject deleteUser(String uname, String reservationid){
    	List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", delete_tag));
        params.add(new BasicNameValuePair("uname", uname));
        params.add(new BasicNameValuePair("reservationid", reservationid));
        //Uses JSONParser object created in the contructor inorder to access
        //the function getJSONFromUrl
        JSONObject json = jsonParser.getJSONFromUrl(deleteURL,"POST", params);
    	return json;
    }
    
    
    
    
    
    
    
    public JSONObject getReservations(String username){
    	List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", getReservations_tag));
        params.add(new BasicNameValuePair("username",username));
        //Uses JSONParser object created in the contructor inorder to access
        //the function getJSONFromUrl
        JSONObject json = jsonParser.getJSONFromUrl(getReservationsURL,"GET", params);
    	return json;
    }
    
    
    
    
    /**
     * Function to change password
     **/

    public JSONObject chgPass(String newpas, String email){
    	//Building parameters
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", chgpass_tag));
        params.add(new BasicNameValuePair("newpas", newpas));
        params.add(new BasicNameValuePair("email", email));
        //Uses JSONParser object created in the constructor in order to access
        //the function getJSONFromUrl
        JSONObject json = jsonParser.getJSONFromUrl(chgpassURL,"POST",params);
        return json;
    }

    
    
    
    /**
     * Function to reset the password
     **/
    public JSONObject forPass(String forgotpassword){
    	//Building parameters 
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", forpass_tag));
        params.add(new BasicNameValuePair("forgotpassword", forgotpassword));
        //Uses JSONParser object created in the contructor inorder to access
        //the function getJSONFromUrl
        JSONObject json = jsonParser.getJSONFromUrl(forpassURL, "POST", params);
        return json;
    }

    
    
    
     /**
      * Function to  Register
      **/
    public JSONObject registerUser(String fname, String lname, String email, String uname, String password){
    	
    	
    	
    	
    	
    	Log.d("UserFunctions","Now im in register User from UserFunctions line102");
        
    	
    	
    	
    	// Building Parameters
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", register_tag));
        params.add(new BasicNameValuePair("fname", fname));
        params.add(new BasicNameValuePair("lname", lname));
        params.add(new BasicNameValuePair("email", email));
        params.add(new BasicNameValuePair("uname", uname));
        params.add(new BasicNameValuePair("password", password));
        
        
        
        Log.d("UserFunctions", "Now entering getJSONFromUrl line118");
        
        
        
        JSONObject json = jsonParser.getJSONFromUrl(registerURL,"POST",params);
        
        
        Log.d("UserFunctions", "Now im am leaving register User from UserFunctions line125");
        
        
        return json;
    }

    /**
     * Function to logout user
     * Resets the temporary data stored in SQLite Database
     * */
    public boolean logoutUser(Context context){
    	Log.d("Database", "MAYBE THE PROBLEM IS HERE?");
        DatabaseHandler db = new DatabaseHandler(context);
        db.resetTables();
        return true;
    }
    
    /**
     * Function to create reservation
     **/
    public JSONObject reserveUser(String startDate, String startTime, String endDate, String endTime, String uname, String license, String state, String credit, String code, String expdate){
    	Log.d("UserFunction","HI I JUST ENTERED THE USERFUNCTION!!");
    	List<NameValuePair> params = new ArrayList<NameValuePair>();
    	params.add(new BasicNameValuePair("tag",reservation_tag));
    	params.add(new BasicNameValuePair("startDate",startDate));
    	params.add(new BasicNameValuePair("startTime",startTime));
    	params.add(new BasicNameValuePair("endDate",endDate));
    	params.add(new BasicNameValuePair("endTime",endTime));
    	params.add(new BasicNameValuePair("uname",uname));
    	params.add(new BasicNameValuePair("license",license));
    	params.add(new BasicNameValuePair("state",state));
    	params.add(new BasicNameValuePair("credit",credit));
    	params.add(new BasicNameValuePair("code",code));
    	params.add(new BasicNameValuePair("expdate",expdate));
    	Log.d("UserFunciton","BYE IM JUST LEAVING THIS AND GOING TO JSONParser");
    	JSONObject json = jsonParser.getJSONFromUrl(reservationURL,"POST",params);
    	
    	return json;
    }

}

