/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 *
 * 
 * This activity file which is used to 
 * reset the user password incase the user forgot their 
 * password. A email is send to users email to reset the 
 * user password. 
 */
package com.example.betweenthelines;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.library.UserFunctions;

public class PasswordReset extends ActionBarActivity {

	//Declaration of variables
	//For Button and the Edit Text found in the password_reset.xml
	EditText email;
	TextView alert;
	Button resetpass;
	
	/**
     * Called when the activity is first created.
     * JSON Response node names.
     */
	private static String KEY_SUCCESS = "success";
	private static String KEY_ERROR = "error";

	/**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState){
    	super.onCreate(savedInstanceState);
	  
    	//When the app first runs, it will be directed to password_reset.xml
        setContentView(R.layout.password_reset);

        //This gets the value of the Buttons
        //by the id initialized within the layout password_reset.xml
        Button login = (Button) findViewById(R.id.bktolog);
        
        //This initializes the action when a certain button is pressed
        //The Button Back to Login is activated.
        login.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View view) {
        		
        		//If the Back to Login button is clicked then it will
        		//be redirected to the activity called Login.java
        		Intent myIntent = new Intent(view.getContext(), Login.class);
	            startActivityForResult(myIntent, 0);
	            finish();
        	}
        });

        //If the Button Back to Login is not activated, then
        //initialize variables
        email = (EditText) findViewById(R.id.forpas);
        alert = (TextView) findViewById(R.id.alert);
	    resetpass = (Button) findViewById(R.id.respass);
	    
	    //This initializes the action when a certain button is pressed
	    //The Button Reset Password is activated
	    resetpass.setOnClickListener(new View.OnClickListener() {
	    	@Override
	        public void onClick(View view) {
	    		NetAsync(view);
	    	}
	    });
	        
    }
	
    
    /**
     * Async Task to check whether internet connection is working.
     **/
    //This class allows to perform background operations 
    //and publish results on the UI thread without having 
    //to manipulate threads and/or handlers
    private class NetCheck extends AsyncTask<String,String,Boolean>
    {
    	private ProgressDialog nDialog;
	    	
	    @Override
	    //This is before it executes
	    protected void onPreExecute(){
	    	super.onPreExecute();
	        nDialog = new ProgressDialog(PasswordReset.this);
	        nDialog.setMessage("Loading..");
	        nDialog.setTitle("Checking Network");
	        nDialog.setIndeterminate(false);
	        nDialog.setCancelable(true);
	        nDialog.show();
	    }
	    
        /**
         * Gets current device state and checks for working internet connection by trying Google.
        **/
        //This is a thread that runs in the background
	    @Override
	    protected Boolean doInBackground(String... args){
	    	
        	//The following snippet shows how to use the ConnectivityManager to query the active 
        	//network and determine if it has Internet connectivity.
	    	ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
	        NetworkInfo netInfo = cm.getActiveNetworkInfo();
	        
	        if (netInfo != null && netInfo.isConnected()) {
	        	try{
	        		URL url = new URL("http://www.google.com");
	                HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
	                urlc.setConnectTimeout(3000);
	                urlc.connect();
	                
	                if (urlc.getResponseCode() == 200) {
	                	return true;
	                }
	        	}
	            catch (MalformedURLException e1) {
	            	// TODO Auto-generated catch block
	                e1.printStackTrace();
	            } 
	        	catch (IOException e) {
	        		// TODO Auto-generated catch block
	        		e.printStackTrace();
	            }
	        }
	        return false;
	    }
	    
        //This is done after the doInBackground.
        //The concrete type bound to result is the type of 
        //the return value from doInBackground, and thus 
        //the type of the parameter to onPostExecute.	    
	    @Override
	    protected void onPostExecute(Boolean th){
	    	if(th == true){
	    		nDialog.dismiss();
                //If the return value from doInBackground is true
            	//then ProcessRegister.execute() is activated.
	            new ProcessRegister().execute();
	    	}
	        else{
	        	nDialog.dismiss();
	        	//Otherwise an error message is sent
	            alert.setText("Error in Network Connection");
	        }
	    }
    }


    private class ProcessRegister extends AsyncTask<String, String, JSONObject> {
    	
    	private ProgressDialog pDialog;
    	
	    String forgotpassword;
	        
	    @Override
	    protected void onPreExecute() {
	    	super.onPreExecute();
	    	
	    	forgotpassword = email.getText().toString();

	        pDialog = new ProgressDialog(PasswordReset.this);
	        pDialog.setTitle("Contacting Servers");
	        pDialog.setMessage("Getting Data ...");
	        pDialog.setIndeterminate(false);
	        pDialog.setCancelable(true);
	        pDialog.show();
	    }

	    //In the background access the Database using JSONObject
	    @Override
	    protected JSONObject doInBackground(String... args) {
	    	//Create an object to UserFunctions in order to access loginUser function
        	//which is located within UserFunctions.java
	    	UserFunctions userFunction = new UserFunctions();
	    	/* When calling forPass, the forgotpassword(email) is sent as a parameter.
             * The JSON response is sent back from loginUser() function.
             */
	        JSONObject json = userFunction.forPass(forgotpassword);
	        return json;
	    }

	    @Override
	    protected void onPostExecute(JSONObject json) {
	        /**
	        * Checks if the Password Change Process is sucesss
	        **/
	        try {
	        	if (json.getString(KEY_SUCCESS) != null) {
	        		alert.setText("");
	                String res = json.getString(KEY_SUCCESS);
	                String red = json.getString(KEY_ERROR);
	                
	                if(Integer.parseInt(res) == 1){
	                	pDialog.dismiss();
	                    alert.setText("A recovery email is sent to you, see it for more details.");
	                }
	                else if (Integer.parseInt(red) == 2){    
	                	pDialog.dismiss();
	                    alert.setText("Your email does not exist in our database.");
	                }
	                else {
	                    pDialog.dismiss();
	                    alert.setText("Error occured in changing Password");
	                }
	        	}
	        }
	        catch (JSONException e) {
	        	e.printStackTrace();
	        }
	    }	        
    }
	            
    public void NetAsync(View view){
    	new NetCheck().execute();
    }	            
}





