/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */
package com.example.betweenthelines;


import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.example.library.DatabaseHandler;
import com.example.library.UserFunctions;
 
public class ViewReservations extends ListActivity {
 
    ArrayList<HashMap<String, String>> reservationList;

    // JSON Node names
    private static final String KEY_SUCCESS = "success";
    private static final String KEY_RESERVATIONS = "reservations";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_RESERVATIONID = "reservationid";
    
 
    JSONArray reservations = null;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.all_reservations);

        
        reservationList = new ArrayList<HashMap<String, String>>();
        
        new LoadReservations().execute();
        
        
        // Getting listview from xml
        ListView lv = getListView();
         
        // Creating a button - Load More
        Button btnBack = new Button(this);
        btnBack.setText("Back to Reservation");
         
        // Adding button to listview at footer
        lv.addFooterView(btnBack);
        
        lv.setOnItemClickListener(new OnItemClickListener(){
        	 @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 // getting values from selected ListItem
  
                 // Starting new intent
                 Intent in = new Intent(getApplicationContext(), Reservation.class);
                 startActivity(in);
             }
        });
        
        
        // view products click event
        btnBack.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View view) {
                // Launching All products Activity
                Intent i = new Intent(getApplicationContext(), Reservation.class);
                startActivity(i);
 
            }
        });
         
    }

 
    /**
     * Background Async Task to Load all product by making HTTP Request
     * */
    private class LoadReservations extends AsyncTask<String, String, JSONObject> {
    	String username;
    	
    	private ProgressDialog pDialog;
        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            
            DatabaseHandler db = new DatabaseHandler(getApplicationContext());
            HashMap<String,String> user = new HashMap<String, String>(); 
    
             user = db.getUserDetails();  
             username = user.get("uname");
            
            
            pDialog = new ProgressDialog(ViewReservations.this);
            pDialog.setMessage("Loading reservations. Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
 
        /**
         * getting All products from url
         * */
        protected JSONObject doInBackground(String... args) {
            // Building Parameters
        	UserFunctions userFunction = new UserFunctions();
        	
        	JSONObject json = userFunction.getReservations(username);
        	
        	
        	
            Log.d("ViewReservations",json.toString());
            
            
            
            return json;
        }
        
        @Override
        protected void onPostExecute(JSONObject json) {
            try {
            	
            	Log.d("ViewReservations","THIS IS BACK FROM THE PHP FILES");
            	
            	
            	if(json.getString(KEY_SUCCESS) != null){
            		
            		String res = json.getString(KEY_SUCCESS);
            		
            		if(Integer.parseInt(res) == 1){
                        pDialog.setMessage("Displaying reservations");
                        pDialog.setTitle("Getting Data");
                        //Creates an object to DatabaseHandler
                        
                        Log.d("ViewReservations","MAYBE I GOT IT HERE LINE152");
            		
                     // products found
                        // Getting Array of Products
                        reservations = json.getJSONArray(KEY_RESERVATIONS);
                        
                     // looping through All Products
                        for (int i = 0; i < reservations.length(); i++) {
                            JSONObject c = reservations.getJSONObject(i);
                            // Storing each json item in variable
                            String aUser= c.getString(KEY_USERNAME);
                            String reservationid = c.getString(KEY_RESERVATIONID);
     
                            // creating new HashMap
                            HashMap<String, String> map = new HashMap<String, String>();
     
                            // adding each child node to HashMap key => value
                            map.put(KEY_USERNAME, aUser);
                            map.put(KEY_RESERVATIONID, reservationid);
     
                            // adding HashList to ArrayList
                            reservationList.add(map);
                            pDialog.dismiss();
                         // updating UI from Background Thread
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    /**
                                     * Updating parsed JSON data into ListView
                                     * */
                                    ListAdapter adapter = new SimpleAdapter(
                                            ViewReservations.this, reservationList,R.layout.list_reservations, new String[] { KEY_USERNAME,KEY_RESERVATIONID},new int[] { R.id.pid, R.id.name });
                                    // updating listview
                                    setListAdapter(adapter);
                                }
                            });
                        }
            		} else {
            			pDialog.dismiss();
            			Toast.makeText(getApplicationContext(),
                                "You currently have no reservations", Toast.LENGTH_SHORT).show();
                    }
            	}
            }catch (JSONException e) {
            	e.printStackTrace();
            }
       }
        
        
        
        
        
        
 

    }
}