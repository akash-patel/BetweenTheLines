/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

package com.example.betweenthelines;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.library.DatabaseHandler;
import com.example.library.UserFunctions;

public class Reservation extends ActionBarActivity {

	Button btnLogout;
	Button btnCreateRes;
	Button btnExtend;
	Button btnDelete;
	Button btnView;
	
	EditText IdReserve;
	TextView Errors;
	
	private static final String KEY_SUCCESS = "success";
	private static final String KEY_ERROR = "error";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reservation);

		btnLogout = (Button) findViewById(R.id.LogoutRes);
		btnCreateRes = (Button) findViewById(R.id.CreateReserve);
		btnExtend = (Button) findViewById(R.id.Extend);
		btnDelete = (Button) findViewById(R.id.delete);
		btnView = (Button) findViewById(R.id.viewbtn);
		
		
		Errors = (TextView)findViewById(R.id.reserveIDErrorMsg);
		IdReserve = (EditText)findViewById(R.id.reserveId);
		

		

        // view products click event
        btnView.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View view) {
                // Launching All products Activity
                Intent i = new Intent(getApplicationContext(), ViewReservations.class);
                startActivity(i);
 
            }
        });
        
        
        
		/**
		 * Goes to Activity CreateReservation
		 */
		btnCreateRes.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View arg0) {
				Intent createRes = new Intent(getApplicationContext(), CreateReservation.class);
				startActivity(createRes);
			}
		});
		
        /**
         *Logout from the User Panel which clears the data in Sqlite database
         **/
         btnLogout.setOnClickListener(new View.OnClickListener() {
             public void onClick(View arg0) {
                 UserFunctions logout = new UserFunctions();
                 logout.logoutUser(getApplicationContext());
                 Intent login = new Intent(getApplicationContext(), Login.class);
                 login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                 startActivity(login);
                 finish();
             }
         });
         
 		btnExtend.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View arg0) {
				Intent createRes = new Intent(getApplicationContext(), ExtendReservation.class);
				startActivity(createRes);
			}
		});
		
 		
 		btnDelete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
				
				
				if (  !IdReserve.getText().toString().equals("") )
                    NetAsync(view);
				else{
                	Toast.makeText(getApplicationContext(),
                            "Please enter reservation id if you would like to delete reservation", Toast.LENGTH_SHORT).show();
                }
			}
		});
	
	}


    /**
     * Async Task to check whether internet connection is working.
     **/
    //This class allows to perform background operations 
    //and publish results on the UI thread without having 
    //to manipulate threads and/or handlers
    private class NetCheck extends AsyncTask<String,String,Boolean>
    {
        private ProgressDialog nDialog;
       
        
        @Override
        //This is before it executes
        protected void onPreExecute(){
        	
        	
        	
        	Log.d("Reservation","THIS IS NETCHECK");
        	
        	
        	
            super.onPreExecute();
            nDialog = new ProgressDialog(Reservation.this);
            nDialog.setTitle("Checking Network");
            nDialog.setMessage("Loading..");
            nDialog.setIndeterminate(false);
            nDialog.setCancelable(true);
            nDialog.show();
        }
        
        
        
        
        
        /**
         * Gets current device state and checks for working internet connection by trying Google.
        **/
        //This is a thread that runs in the background
        @Override
        protected Boolean doInBackground(String... args)
        {

        	
        	
        	
        	Log.d("Reservation","THIS IS DOINBACKGROUND line213");
        	
        	
        	
        	
        	//The following snippet shows how to use the ConnectivityManager to query the active 
        	//network and determine if it has Internet connectivity.
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            
            if (netInfo != null && netInfo.isConnected()) {
                try {
                    URL url = new URL("http://www.google.com");
                    HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
                    urlc.setConnectTimeout(3000);
                    urlc.connect();
                    if (urlc.getResponseCode() == 200) {
                        return true;
                    }
                } 
                catch (MalformedURLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } 
                catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            return false;

        }
        //This is done afterward the doInBackground.
        //The concrete type bound to result is the type of 
        //the return value from doInBackground, and thus 
        //the type of the parameter to onPostExecute.
        @Override
        protected void onPostExecute(Boolean th){
            if(th == true){
                //If the return value from doInBackground is true
            	//then ProcessLogin.execute() is activated.
            	
            	
            	
            	Log.d("Reservation","THIS IS BEFORE GETTING INTO THE processing reservation");
            	

            	nDialog.dismiss();
                new ProcessDelete().execute();
            }
            else{
            	//Otherwise an error message is sent
                nDialog.dismiss();
                Errors.setText("Error in Network Connection");
            }
        }
    }

    
    /**
     * Async Task to get and send data to My Sql database through JSON respone.
     **/
    //If everything goes well in doInBackground then this function is called.
    private class ProcessDelete extends AsyncTask<String, String, JSONObject> {
    
    	private ProgressDialog pDialog;

        String username,reservationid;

        @Override
        //Before executing, initialize variables
        protected void onPreExecute() {
            super.onPreExecute();

            
            DatabaseHandler db = new DatabaseHandler(getApplicationContext());
            HashMap<String,String> user = new HashMap<String, String>(); 
    
             user = db.getUserDetails();  
             username = user.get("uname");
            
             
            
            Log.d("Reservation","THIS IS IN THE PROCESSreservation");
            
            

            
            reservationid = IdReserve.getText().toString();
            
            
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setTitle("Contacting Servers");
            pDialog.setMessage("Logging in ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }
        
        //In the background access the Database using JSONObject
        @Override
        protected JSONObject doInBackground(String... args) {
        	
        	//Create an object to UserFunctions in order to access loginUser function
        	//which is located within UserFunctions.java
            UserFunctions userFunction = new UserFunctions();
            
            
            /* When calling loginUser, the username and password are sent as parameters.
             * The JSON response is sent back from loginUser() function.
             */
            
            
            
            Log.d("Reservation","THIS IS BEFORE DOING THE JSON LOGIN USER LINE292");
            
            
            
            
            JSONObject json = userFunction.deleteUser(username, reservationid);
            
            
            
            Log.d("Delete reservation",json.toString());
            
            
            
            return json;
        }

        @Override
        protected void onPostExecute(JSONObject json) {
            try {
            	
            	
            	
            	Log.d("Reservations","THIS IS BACK FROM THE PHP FILES");
            	
            	
            	
               if (json.getString(KEY_SUCCESS) != null) {
            	   
            	   
            	   Log.d("Login","THIS IS WHERE I GOT THE ERROR?");
            	   
            	   
                    String res = json.getString(KEY_SUCCESS);
                    String red = json.getString(KEY_ERROR);

                    if(Integer.parseInt(res) == 1){
                        pDialog.setMessage("Deleting reservation");
                        pDialog.setTitle("Getting Data");
                        //Creates an object to DatabaseHandler
                        
                        
                        
                        Log.d("Login","MAYBE I GOT IT HERE LINE361");
                        
             

                        /**
                        *If JSON array details are stored in SQlite it launches the User Panel.
                        **/
                        //After the login was verified, the app will go to activity called Main.java
                        //Which is the main page for the users account
                      
                        Intent upanel = new Intent(getApplicationContext(), ViewReservations.class);
                        upanel.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        pDialog.dismiss();
                        startActivity(upanel);
                        
                        /**
                         * Close Login Screen
                         **/
                        finish();
                    }
                    else if (Integer.parseInt(red) == 2){
                    	pDialog.dismiss();
                    	Errors.setText("You cannot delete a reservation that has already begun or is within 30 minutes of its starting time.");
                    }
                    else{

                        pDialog.dismiss();
                        Errors.setText("Error occurred when deleting reservation.");
                    }
                }
            } 
            catch (JSONException e) {
                e.printStackTrace();
            }
       }
    }

    
    
    
    
    //This function is called when both the Username and Password are inputted
    public void NetAsync(View view){
    	//Creates and object of the class and called the function
        new NetCheck().execute();
    }

}
