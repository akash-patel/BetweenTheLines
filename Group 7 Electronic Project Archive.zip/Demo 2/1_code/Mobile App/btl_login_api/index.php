<?php

/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

/**
 *PHP API for Login, Register, Changepassword, Resetpassword Requests and for Email Notifications.
 *This is the file which handles POST and GET request. It sends the JSON response on successful result.
 **/
//isset determines if a variable is set and is not NULL


if (isset($_POST['tag']) && $_POST['tag'] != '') {
    // Get tag
    $tag = $_POST['tag'];

    // Include Database handler

    require_once 'include/DB_Functions.php';
    //Call to contructor within DB_Functions.php
    $db = new DB_Functions();

    // response Array
    //This is an associative array 
    //Associative arrays are arrays that use named keys that you assign to them.
    //$array['tag'] will be equal to $tag
    $response = array("tag" => $tag, "success" => 0, "error" => 0);






    // check for tag type login
    if ($tag == 'login') {
        // Request type is check Login
        $username = $_POST['username'];
        $password = $_POST['password'];

        // check for user
        $user = $db->getUserByUsernameAndPassword($username, $password);

        if ($user != false) {
            // user found
            // echo json with success = 1
            $response["success"] = 1;
            $response["user"]["uname"] = $user["username"];
            $response["user"]["fname"] = $user["firstname"];
            $response["user"]["lname"] = $user["lastname"];
            $response["user"]["email"] = $user["email"];
            //echos the response
            echo json_encode($response);
        } else {
            // user not found
            // echo json with error = 1
            $response["error"] = 1;
            $response["error_msg"] = "Incorrect username or password!";
            //echos the response
            echo json_encode($response);
        }
    } 






    //check tag type for chgpass
  	else if ($tag == 'chgpass'){

  		$email = $_POST['email'];
  		$newpassword = $_POST['newpas'];  


  		$subject = "Change Password Notification";
        $message = "Hello User,\n\nYour Password is sucessfully changed.\n\nRegards,\nBetween The Line Team.";
        $from = "contact@BetweenTheLines.com";
        $headers = "From:" . $from;
	
		if ($db->isUserExistedEmail($email)) {
			$user = $db->forgotPassword($email, $newpassword);
			
			if ($user) {
         		$response["success"] = 1;
          		mail($email,$subject,$message,$headers);
         		echo json_encode($response);
			}
			else {
				$response["error"] = 1;
				echo json_encode($response);
			}
            // user is already existed - error response
        } 
        else {

            $response["error"] = 2;
            $response["error_msg"] = "User not exist";
            echo json_encode($response);

		}
	}




    else if($tag == 'delete'){
        $uname = $_POST['uname'];
        $reservationid = $_POST['reservationid'];



        if($db->isDeletable($uname,$reservationid)){

            $response = $db->DeleteReservation($uname, $reservationid);
            
            if($response != false){
                $response["success"] = 1;
                $response["message"] = "Reservation deleted successfully."; 
                echo json_encode($response);
            }else{
                $response["error"] = 1;
                $response["message"] = "Error occured when deleting reservation.";
                echo json_encode($response);
            }
        }else{
            $response["error"] = 2;
            $response["error_msg"] = "You cannot delete a reservation that has already begun or is within 30 minutes of its starting time.";
            echo json_encode($response);
        }
    }

    //checks tag for reservation
    else if ($tag == 'reservation'){

        $startDate = $_POST['startDate'];
        $startTime = $_POST['startTime'];
        $endDate = $_POST['endDate'];
        $endTime = $_POST['endTime'];
        $uname = $_POST['uname'];
        $license = $_POST['license'];
        $state = $_POST['state'];
        $credit = $_POST['credit'];
        $code = $_POST['code'];
        $expdate = $_POST['expdate'];


        //Format used below: YYYY-MM-DD HH:MM:SS
        $startdatetime = $startDate . ' ' . $startTime;
        $enddatetime = $endDate . ' ' . $endTime;

        $startdatetimesec = strtotime($startdatetime);
        $enddatetimesec = strtotime($enddatetime);

        /* time/900 represents the number of 15 minute intervals. This is because
        time is in seconds and the 15 minutes is 900 seconds*/
        $space = $db->isThereSpace($startdatetimesec, $enddatetimesec);

        if($space){
            $reserve = $db->CreateReservation( $uname, $license, $state, $startdatetime, $enddatetime, $startdatetimesec, $enddatetimesec, $credit, $code, $expdate);
            
            if ($reserve != false) {
                // user stored successfully
                
       

                $response["success"] = 1;
                $response["reserve"]["uname"] = $reserve["username"];
                $response["reserve"]["reservationid"] = $reserve["reservationid"];
                $response["reserve"]["license"] = $reserve["licenseplate"];
                $response["reserve"]["startdatetime"] = $reserve["startdatetime"];
                $response["reserve"]["enddatetime"] = $reserve["enddatetime"];
                $response["reserve"]["startdatetimesec"] = $reserve["startdatetimesec"];
                $response["reserve"]["enddatetimesec"] = $reserve["enddatetimesec"];
                $response["reserve"]["credit"] = $reserve["cc"];
                           
                echo json_encode($response);
            } 
            else {
                // user failed to store
                $response["error"] = 1;
                $response["error_msg"] = "JSON Error occured in Reservation";
                echo json_encode($response);    
            }
        }
        else{
            // no space available
            // echo json with error = 1
            $response["error"] = 1;
            $response["error_msg"] = "Not enough room in the garage!";
            //echos the response
            echo json_encode($response);
        }
    }









	//checks tag for forpass
	else if ($tag == 'forpass'){
		$forgotpassword = $_POST['forgotpassword'];

		$randomcode = $db->random_string();
  
  		$subject = "Password Recovery";
        $message = "Hello User,\n\nYour Password is sucessfully changed. Your new Password is $randomcode . Login with your new Password and change it in the User Panel.\n\nRegards,\nBetween The Lines team.";
        $from = "contact@BetweenTheLines.com";
        $headers = "From:" . $from;
	
		if ($db->isUserExisted($forgotpassword)) {

 			$user = $db->forgotPassword($forgotpassword, $randomcode);
			
			if ($user) {
         		$response["success"] = 1;
          		mail($forgotpassword,$subject,$message,$headers);
         		echo json_encode($response);
			}
			else {
				$response["error"] = 1;
				echo json_encode($response);
			}
            // user is already existed - error response                     
        } 
        else {

            $response["error"] = 2;
            $response["error_msg"] = "User not exist";
             echo json_encode($response);
		}
	}







	//checks tag for register
	else if ($tag == 'register') {
        // Request type is Register new user
        $fname = $_POST['fname'];
		$lname = $_POST['lname'];
        $email = $_POST['email'];
		$uname = $_POST['uname'];
        $password = $_POST['password'];

        // check if user is already existed
        if ($db->isUserExisted($uname)) {
        	// user is already existed - error response
            $response["error"] = 2;
            $response["error_msg"] = "User already existed";
            echo json_encode($response);
        } 
        //checks if user inputted a valid email
        else if(!$db->validEmail($email)){
            $response["error"] = 3;
            $response["error_msg"] = "Invalid Email Id";
            echo json_encode($response);             
		}
		else {
        	// store user
        	$user = $db->storeUser($fname, $lname, $email, $uname, $password);
        
        	if ($user != false) {
        		// user stored successfully
            	$response["success"] = 1;
            	$response["user"]["uname"] = $user["username"];
            	$response["user"]["fname"] = $user["firstname"];
	    		$response["user"]["lname"] = $user["lastname"];
            	$response["user"]["email"] = $user["email"];
                      
            	echo json_encode($response);
        	} 
        	else {
            	// user failed to store
            	$response["error"] = 1;
            	$response["error_msg"] = "JSON Error occured in Registration";
            	echo json_encode($response);    
        	}
    	} 
    }

    else {
        $response["error"] = 3;
        $response["error_msg"] = "JSON ERROR";
        echo json_encode($response);
    }
} 
else if(isset($_GET["tag"]))
{
    $tag = $_GET['tag'];

    // Include Database handler

    require_once 'include/DB_Functions.php';
    //Call to contructor within DB_Functions.php
    $db = new DB_Functions();

    // response Array
    //This is an associative array 
    //Associative arrays are arrays that use named keys that you assign to them.
    //$array['tag'] will be equal to $tag
    //$response = array("tag" => $tag, "success" => 0, "error" => 0);

    $username = $_GET['username'];
    // get a product from products table
    $result = mysql_query("SELECT *FROM reservations WHERE username = '$username'");
 
   // if (!empty($result)) {
        // check for empty result
        if (mysql_num_rows($result) > 0) {
            // user node
            $response["reservations"] = array();

            while($row = mysql_fetch_array($result)){
            
 
            $reservations = array();
            $reservations["username"] = $row["username"];
            $reservations["reservationid"] = $row["reservationid"];
            $reservations["startdatetime"] = $row["startdatetime"];
            $reservations["enddatetime"] = $row["enddatetime"];
            // success
            array_push($response["reservations"], $reservations);
            }
            $response["success"] = 1;
 
            
 
            // echoing JSON response
            echo json_encode($response);
        } else {
            // no product found
            $response["success"] = 0;
            $response["message"] = "No product found";
 
            // echo no users JSON
            echo json_encode($response);
        }


}else {
    echo "Between The Lines Login API";
}
?>
