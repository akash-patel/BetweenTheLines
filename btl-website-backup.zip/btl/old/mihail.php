<HTML>
<div align="center">
<h1>Photosensor Simulation</h1>

Occupancy for floor 
<?php 
	session_start();	
	echo $_SESSION['floor']
?>


<script type="text/javascript" >
<!--

function btnClick(checkedValue) {
    var x = document.getElementById("mytable").getElementsByTagName("td");

	if (x[checkedValue].style.backgroundColor == "green")
		{
		x[checkedValue].style.backgroundColor = "red";
		}
	else
		{
		x[checkedValue].style.backgroundColor = "green";          
		}		
}
</script>

 <style>
    div
    {
    text-align: center; 
    text-indent: 0px; 
    padding: 0px 0px 0px 0px; 
    margin: 0px 0px 0px 0px;
    }
    td.td
    {
                 border-width : 1px; 
                 background-color: #FF0000;
                 text-align:center;

    }
    </style>  
  <body onload="btnClick(7);">
  <div>  
    <table id = "mytable" width="100%" border="1" cellpadding="3" cellspacing="2" style="background-color: #ffffff;">
      <tr valign="top">
      <td class = "td" OnClick = "btnClick('0')"><br />  </td>
      <td class = "td" OnClick = "btnClick('1')"><br />  </td>
	  <td class = "td" OnClick = "btnClick('2')"><br />  </td>
      </tr>
      <tr valign="top">
      <td class = "td" OnClick = "btnClick('3')"><br />  </td>
      <td class = "td" OnClick = "btnClick('4')"><br />  </td>
	  <td class = "td" OnClick = "btnClick('5')"><br />  </td>
      </tr>
	  <tr valign="top">
      <td class = "td" OnClick = "btnClick('6')"><br />  </td>
      <td class = "td" OnClick = "btnClick('7')"><br />  </td>
	  <td class = "td" OnClick = "btnClick('8')"><br />  </td>
      </tr>
    </table>
  </div>
</tr>
<br>

  </body>
</html>
</div>
</HTML>