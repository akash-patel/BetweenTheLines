<HTML>
<div align="center">
<h1>Photosensor Simulation</h1>

Occupancy for floor 

<?php 
	session_start();	
	echo $_SESSION['floor']

	$floor = $_SESSION['floor'];

	// Include database connection settings
	include('../config.inc');
	$_SESSION['error'] = NULL;


?>

<script type="text/javascript" >

	function btnClick(checkedValue) 
	{
		var x = document.getElementById("mytable").getElementsByTagName("td");

		if (x[checkedValue].style.backgroundColor == "green")
		{
			x[checkedValue].style.backgroundColor = 'red';
		}
		else
		{
			x[checkedValue].style.backgroundColor = "green";          
		}		
	}
</script>

<style>
div
{
	text-align: center; 
	text-indent: 0px; 
	padding: 0px 0px 0px 0px; 
	margin: 0px 0px 0px 0px;
}

td.td
{
	border-width : 1px; 
	background-color: #FF0000;
	text-align:center;
}
</style>  

<body>
	<div>  
	<table id = "mytable" width="100%" border="1" cellpadding="3" cellspacing="2" style="background-color: #ffffff;">
	<tr valign="top">

	<?php

		// Include database connection settings
		include('../config.inc');
		$_SESSION['error'] = NULL;

		if (!$result) die ("Database access failed: " . mysql_error());

		$floor = $_SESSION['floor'];

		for($i = 1; $i <= 3; $i++)
		{
			$query = "SELECT istaken FROM occupancy WHERE MID(psensorid, 1, 1)='$floor' AND MID(psensorid, 2, 2)='$i'";
			$result = mysql_query($query);
			if (!$result) die ("Database access failed: " . mysql_error());

			switch($result)
			{
				case "0":
					echo "<td class = ". "td". "OnClick =". "btnClick(", ($i-1). ")".  "style=". "background-color=green". "><br />  </td>";
					break;
				case "1":
					echo "<td class = ". "td". "OnClick =". "btnClick(", ($i-1). ")".  "style=". "background-color=red". "><br />  </td>";
					break;
			}
		}

		echo '</tr>';
		echo '<tr valign="top">';

		for($i = 4; $i <= 6; $i++)
		{
			$query = "SELECT istaken FROM occupancy WHERE MID(psensorid, 1, 1)='$floor' AND MID(psensorid, 2, 2)='$i'";
			$result = mysql_query($query);
			if (!$result) die ("Database access failed: " . mysql_error());

			switch($result)
			{
				case "0":
					echo "<td class = ". "td". "OnClick =". "btnClick(", ($i-1). ")".  "style=". "background-color=green". "><br />  </td>";
					break;
				case "1":
					echo "<td class = ". "td". "OnClick =". "btnClick(", ($i-1). ")".  "style=". "background-color=red". "><br />  </td>";
					break;
			}
		}

		echo '</tr>';
		echo '<tr valign="top">';

		for($i = 7; $i <= 9; $i++)
		{
			$query = "SELECT istaken FROM occupancy WHERE MID(psensorid, 1, 1)='$floor' AND MID(psensorid, 2, 2)='$i'";
			$result = mysql_query($query);
			if (!$result) die ("Database access failed: " . mysql_error());

			switch($result)
			{
				case "0":
					echo "<td class = ". "td". "OnClick =". "btnClick(", ($i-1). ")".  "style=". "background-color=green". "><br />  </td>";
					break;
				case "1":
					echo "<td class = ". "td". "OnClick =". "btnClick(", ($i-1). ")".  "style=". "background-color=red". "><br />  </td>";
					break;
			}
		}

		echo '</tr>';

	?>

	</table>
	</div>
	</tr>
	<br>

	</body>
</div>
</HTML>