<HTML>
<div align="center">
	<P> Customer drives up to elevator.</P>
	<img src="elevator.jpg" alt="some_text">
	<input name="newThread2" type="button" value="NEXT" align="center" onclick="window.open('Third.php', '_parent')"/>
</div>
</HTML>