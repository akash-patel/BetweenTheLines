<HTML>
<div align="center">
	<P> Customer drives into parking garage.</P>
	<img src="Drive.gif" alt="some_text">
	<input name="newThread" type="button" value="NEXT" align="center" onclick="window.open('Second.php', '_parent')"/>
</div>
</HTML>