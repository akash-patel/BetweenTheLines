<HTML>
<title>Simulation: Elevator</title>
<div align="center">
	<h1> Customer drives up to elevator.</h1>
	<img src="elevator.jpg" alt="some_text"><br>
	<input name="newThread2" type="button" value="Continue" align="center" onclick="window.open('Third.php', '_parent')"/>
</div>
</HTML>
