

<?php

/**
 * This file contains the PHP functions to register user, 
 * check email is valid, reset password.
 **/

/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */
class DB_Functions {

    private $db;

    //put your code here
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->db->connect();
    }

    // destructor
    function __destruct() {
        
    }


    /**
     * Random string which is sent by mail to reset password
     */

    public function random_string()
    {
        $character_set_array = array();
        $character_set_array[] = array('count' => 7, 'characters' => 'abcdefghijklmnopqrstuvwxyz');
        $character_set_array[] = array('count' => 1, 'characters' => '0123456789');
        $temp_array = array();
    
        foreach ($character_set_array as $character_set) {
            for ($i = 0; $i < $character_set['count']; $i++) {
                $temp_array[] = $character_set['characters'][rand(0, strlen($character_set['characters']) - 1)];
            }
        }
    
        shuffle($temp_array);
        return implode('', $temp_array);
    }


    public function forgotPassword($forgotpassword, $newpassword)
    {
	   $result = mysql_query("UPDATE `users` SET `password` = '$newpassword' WHERE `email` = '$forgotpassword'");
        if ($result) {
            return true;
        }
        else
        {
            return false;
        }

    }

    /**
     * Adding new user to mysql database
     * returns user details
     */
    public function storeUser($fname, $lname, $email, $uname, $password) {

        $result = mysql_query("INSERT INTO users(username, password, firstname, lastname, email ) VALUES('$uname', '$password', '$fname', '$lname','$email' )");
        // check for successful store
        if ($result) {
            // get user details 
            // return user details
            $result = mysql_query("SELECT * FROM users WHERE username = '$uname'");

            return mysql_fetch_array($result);

        } else {

            return false;
        }
    }


    /**
     * Verifies user by email and password
     */
    public function getUserByUsernameAndPassword($username, $password) {
        //Retrieves information from the database

        $query = mysql_query("SELECT * FROM users WHERE username='$username' AND password='$password'");
        // check for result 


        $no_of_rows = mysql_num_rows($query);

        if ($no_of_rows == 1) {

            return mysql_fetch_array($query);
        } 
        else {
            // user not found
            return false;
        }
    }

    public function validEmail($email)
    {
        $isValid = true;
        $atIndex = strrpos($email, "@");
        
        if (is_bool($atIndex) && !$atIndex)
        {
            $isValid = false;
        }
        else
        {
            $domain = substr($email, $atIndex+1);
            $local = substr($email, 0, $atIndex);
            $localLen = strlen($local);
            $domainLen = strlen($domain);
            
            if ($localLen < 1 || $localLen > 64)
            {
                // local part length exceeded
                $isValid = false;
            }
            else if ($domainLen < 1 || $domainLen > 255)
            {
                // domain part length exceeded
                $isValid = false;
            }
            else if ($local[0] == '.' || $local[$localLen-1] == '.')
            {
                // local part starts or ends with '.'
                $isValid = false;
            }
            else if (preg_match('/\\.\\./', $local))
            {
                // local part has two consecutive dots
                $isValid = false;
            }
            else if (!preg_match('/^[A-Za-z0-9\\-\\.]+$/', $domain))
            {
                // character not valid in domain part
                $isValid = false;
            }  
            else if (preg_match('/\\.\\./', $domain))
            {
                // domain part has two consecutive dots
                $isValid = false;
            }
            else if(!preg_match('/^(\\\\.|[A-Za-z0-9!#%&`_=\\/$\'*+?^{}|~.-])+$/', str_replace("\\\\","",$local)))
            {
                // character not valid in local part unless 
                // local part is quoted
                if (!preg_match('/^"(\\\\"|[^"])+"$/', str_replace("\\\\","",$local)))
                {
                    $isValid = false;
                }
            }
        
            if ($isValid && !(checkdnsrr($domain,"MX") || checkdnsrr($domain,"A")))
            {
                // domain not found in DNS
                $isValid = false;
            }
        }
        return $isValid;
    }

 

    /**
     * Check user is existed or not
     */
    public function isUserExisted($uname) {
        $result = mysql_query("SELECT username from users WHERE username = '$uname'");
        $no_of_rows = mysql_num_rows($result);
        if ($no_of_rows > 0) {
            // user existed 
            return true;
        } else {
            // user not existed
            return false;
        }
    }


    public function isUserExistedEmail($email)
    {
        $result = mysql_query("SELECT email from users WHERE email = '$email'");
        $no_of_rows = mysql_num_rows($result);
        
        if($no_of_rows > 0){
            return true;
        }
        else
            return false;
    }


    public function isThereSpace($startdatetimesec, $enddatetimesec) {


        for ($i = $startdatetimesec; $i < $enddatetimesec ; $i+=900) {

            $j = $i + 900;
            $result = mysql_query("SELECT * FROM reservations WHERE startdatetimesec < $j AND enddatetimesec > $i");
            $rows = mysql_num_rows($result);
            if ($rows < 5){
                return $result;
            }
            else
                return false;
                
        }
    }


    public function CreateReservation($uname, $license, $state, $startdatetime, $enddatetime, $startdatetimesec, $enddatetimesec, $credit, $code, $expdate){



        $reservationid = strtotime("now");

        $result = mysql_query("INSERT INTO reservations(username, reservationid, licenseplate, state, startdatetime, enddatetime, startdatetimesec, enddatetimesec, cc, cvv, ccexpdate) VALUES ('$uname', '$reservationid', '$license', '$state' , '$startdatetime','$enddatetime', '$startdatetimesec', '$enddatetimesec', '$credit', '$code', '$expdate')");
               // check for successful store
        if ($result) {
            // get user details 
            // return user details
            $result = mysql_query("SELECT * FROM reservations WHERE reservationid = '$reservationid'");

            return mysql_fetch_array($result);

        } else {

            return false;
        }
    }

    public function isDeletable($uname,$reservationid){
        $query = "SELECT * FROM reservations  WHERE reservationid = '$reservationid'";
        $result = mysql_query($query);
        $startdatetimesec =  mysql_result($result, 0,'startdatetimesec');
        $currenttime = strtotime("now");
        if ($startdatetimesec > ($currenttime+ 1800) ){
            return true;
        }else
            return false;
    }



    public function DeleteReservation($uname, $reservationid){

        $query = "DELETE FROM reservations WHERE reservationid = '$reservationid' and username = '$username' ";
        $result = mysql_query($query);

        if(mysql_affected_rows() > 0){
            return true;
        }else{
            return false;
        }

    }


    public function getAllReservations($uname){
        $query = "SELECT *FROM reservations WHERE username = '$uname'";
        $result = mysql_query($query);

        if(mysql_num_rows($result) > 0){
            return mysql_fetch_array($result);
        }else{
            return false;
        }
    }




}




