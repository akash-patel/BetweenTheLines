<?php

/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

/**
 * Database config variables
 * This file contains constant variables to connect to database.
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "btl_login_api");
?>