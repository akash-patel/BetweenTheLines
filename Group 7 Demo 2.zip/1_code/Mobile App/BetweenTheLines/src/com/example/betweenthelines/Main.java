
/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 *
 * 
 * This is the Main activity file which is the user panel. 
 * The user can change the password in the user panel. 
 * When the user clicks the logout button all the data in 
 * the SQLite database gets cleared.
 */
package com.example.betweenthelines;

import java.util.HashMap;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.library.DatabaseHandler;
import com.example.library.UserFunctions;

public class Main extends ActionBarActivity {
	
	//Declaration of variables
	//For Button found in main.xml
	Button btnLogout;
    Button btnReserve;
    Button changepas;
    String uname;
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //When the app first runs, it will be directed to main.xml
        setContentView(R.layout.main);

        btnLogout = (Button) findViewById(R.id.logout);
        changepas = (Button) findViewById(R.id.btchangepass);
        btnReserve = (Button) findViewById(R.id.reserve);

        //Creates an object to DatabaseHandler
        DatabaseHandler db = new DatabaseHandler(getApplicationContext());

        /**
         * Hashmap to load data from the Sqlite database
         **/
         HashMap<String,String> user = new HashMap<String, String>();
         user = db.getUserDetails();
        
         
         /**
          * Change Password Activity Started
          **/
          //This initializes the action when a certain button is pressed
          //The Button Change Password is activated.
         changepas.setOnClickListener(new View.OnClickListener(){
             public void onClick(View arg0){
                 Intent chgpass = new Intent(getApplicationContext(), ChangePassword.class);
                 startActivity(chgpass);
             }

         });
        
        /**
         * Button redirects to Reservation Activity
         **/
        //This initializes the action when a certain button is pressed
        //The Button Account is activated
        btnReserve.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent modAccount = new Intent(getApplicationContext(), Reservation.class);
				startActivity(modAccount);
			}
		});

        
       /**
        *Logout from the User Panel which clears the data in Sqlite database
        **/
        btnLogout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                UserFunctions logout = new UserFunctions();
                logout.logoutUser(getApplicationContext());
                Intent login = new Intent(getApplicationContext(), Login.class);
                login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(login);
                finish();
            }
        });

        /**
         * Sets user first name and last name in text view.
         **/
        final TextView login = (TextView) findViewById(R.id.textwelcome);
        login.setText("Welcome "+user.get("fname"));
        final TextView lname = (TextView) findViewById(R.id.lname);
        lname.setText(" "+user.get("lname"));


    }
    
}