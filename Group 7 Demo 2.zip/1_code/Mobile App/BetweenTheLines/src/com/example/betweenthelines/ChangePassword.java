/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 */

package com.example.betweenthelines;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.library.DatabaseHandler;
import com.example.library.UserFunctions;

public class ChangePassword extends ActionBarActivity {
	
	/**
     * Called when the activity is first created.
     * JSON Response node names.
     */
	private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";

    //Declaration of variables
  	//For Button and the Edit Text found in the login.xml
    EditText newpass;
    TextView alert;
    Button changepass;
    Button cancel;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //When the app first runs, it will be directed to change_password.xml
        setContentView(R.layout.change_password);

        //This initializes the action when a certain button it pressed
        //The Cancel Button is activated.
        cancel = (Button) findViewById(R.id.btcancel);
        cancel.setOnClickListener(new View.OnClickListener(){
	        public void onClick(View arg0){
	        	//If the Forgot Password button is clicked then it will
        		//be redirected to the activity called Main.java
	        	Intent login = new Intent(getApplicationContext(), Main.class);
	        	startActivity(login);
	            finish();
	        }
        });

        //This gets the value of the Button, Edit Text and TextView
        //by the id initialized within the layout change_password.xml
        newpass = (EditText) findViewById(R.id.newpass);
	    alert = (TextView) findViewById(R.id.alertpass);
	    changepass = (Button) findViewById(R.id.btchangepass);

	    //This initializes the action when a certain button it pressed
        //The Change password Button is activated.
	    changepass.setOnClickListener(new View.OnClickListener() {
	    	@Override
	        public void onClick(View view) {
	    		NetAsync(view);
	    	}
	    });
	    
    }

    /**
     * Async Task to check whether internet connection is working.
     **/
    //This class allows to perform background operations 
    //and publish results on the UI thread without having 
    //to manipulate threads and/or handlers
    private class NetCheck extends AsyncTask<String,String,Boolean>{
    	private ProgressDialog nDialog;

	    @Override
	    //This is before it executes
	    protected void onPreExecute(){
	    	super.onPreExecute();
	        nDialog = new ProgressDialog(ChangePassword.this);
	        nDialog.setMessage("Loading..");
	        nDialog.setTitle("Checking Network");
	        nDialog.setIndeterminate(false);
	        nDialog.setCancelable(true);
	        nDialog.show();
	    }

	    @Override
        /**
         * Gets current device state and checks for working internet connection by trying Google.
        **/
        //This is a thread that runs in the background
	    protected Boolean doInBackground(String... args){
	    	
        	//The following snippet shows how to use the ConnectivityManager to query the active 
        	//network and determine if it has Internet connectivity.
	    	ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
	        NetworkInfo netInfo = cm.getActiveNetworkInfo();

	        if (netInfo != null && netInfo.isConnected()) {
	        	try {
	        		URL url = new URL("http://www.google.com");
	                HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
	                urlc.setConnectTimeout(3000);
	                urlc.connect();
	                
	                if (urlc.getResponseCode() == 200) {
	                	return true;
	                }
	        	} 
	        	catch (MalformedURLException e1) {
	        		// TODO Auto-generated catch block
	                e1.printStackTrace();
	        	} 
	        	catch (IOException e) {
	        		// TODO Auto-generated catch block
	                e.printStackTrace();
	        	}
	            
	        }
	        return false;
	    }
	    
        //This is done afterward the doInBackground.
        //The concrete type bound to result is the type of 
        //the return value from doInBackground, and thus 
        //the type of the parameter to onPostExecute.
	    @Override
	    protected void onPostExecute(Boolean th){
	    	if(th == true){
                //If the return value from doInBackground is true
            	//then ProcessRegister.execute() is activated.
	    		nDialog.dismiss();
	            new ProcessRegister().execute();
	    	}
	        else{
            	//Otherwise an error message is sent
	            nDialog.dismiss();
	            alert.setText("Error in Network Connection");
	        }
	    }
	    
    }	

    /**
     * Async Task to get and send data to My Sql database through JSON respone.
     **/
    //If everything goes well in doInBackground then this function is called.
    private class ProcessRegister extends AsyncTask<String, String, JSONObject> {
    	private ProgressDialog pDialog;

    	String newpas,email;
	    @Override
	    //Before executing, initialize variables
	    protected void onPreExecute() {
	    	super.onPreExecute();
	    	
	        //Creates an object to DatabaseHandler
	        DatabaseHandler db = new DatabaseHandler(getApplicationContext());

	        HashMap<String,String> user = new HashMap<String, String>();
	        user = db.getUserDetails();

	        //gets the new password from user
	        newpas = newpass.getText().toString();
	        email = user.get("email");

	        Log.d("ChangePassword",newpas);
	        Log.d("ChangePassword",email);
	        pDialog = new ProgressDialog(ChangePassword.this);
	        pDialog.setTitle("Contacting Servers");
	        pDialog.setMessage("Getting Data ...");
	        pDialog.setIndeterminate(false);
	        pDialog.setCancelable(true);
	        pDialog.show();
	    }

   	    //In the background access the Database using JSONObject
	    @Override
	    protected JSONObject doInBackground(String... args) {
        	//Create an object to UserFunctions in order to access chgPass function
        	//which is located within UserFunctions.java
	    	UserFunctions userFunction = new UserFunctions();
	    	JSONObject json = userFunction.chgPass(newpas, email);
	        Log.d("Button", "Register");
	        return json;
	    }

	    @Override
	    protected void onPostExecute(JSONObject json) {
	    	try {
	    		if (json.getString(KEY_SUCCESS) != null) {
	    			alert.setText("");
	                String res = json.getString(KEY_SUCCESS);
	                String red = json.getString(KEY_ERROR);

	                if (Integer.parseInt(res) == 1) {
	                /**
	                 * Dismiss the process dialog
	                 **/
	                	pDialog.dismiss();
	                    alert.setText("Your Password is successfully changed.");
	                    
                        /**
                         * Launch Account screen
                         **/ 
                        Intent bkaccount = new Intent(getApplicationContext(), Main.class);

                        /**
                         * Close all views before launching Registered screen
                        **/
                        bkaccount.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        pDialog.dismiss();
                        startActivity(bkaccount);
                        finish();
                        
	                } 
	                else if (Integer.parseInt(red) == 2) {
	                    pDialog.dismiss();
	                    alert.setText("Invalid, old Password.");
	                } 
	                else {
	                    pDialog.dismiss();
	                    alert.setText("Error occured in changing Password.");
	                }

	    		}
	    	} 
	    	catch (JSONException e) {
	                e.printStackTrace();
	    	}
	    }
    }
	
    //This function is called when both the Username and Password are inputted
    public void NetAsync(View view){
    	//Creates and object of the class and called the function
    	new NetCheck().execute();
    }
    
}


