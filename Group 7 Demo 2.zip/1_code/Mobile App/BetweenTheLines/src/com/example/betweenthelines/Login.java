
/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 *
 * 
 * This is the Login activity, which handles login request. It
 * sends the users username and password  through JSON response to verify 
 * whether the username/password combination is correct. We get a success 
 * message through JSON and if the login details are right and the 
 * user will be redirected to the User panel screen. We also get the 
 * user details as JSON response if the Login is a success and it will 
 * be stored in SQLite database which is similar to cookie. Async task 
 * is used to check working internet connection and to get data from 
 * the MySQL server.
 * */

package com.example.betweenthelines;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.library.DatabaseHandler;
import com.example.library.UserFunctions;

public class Login extends ActionBarActivity {

	//Declaration of variables
	//For Button and the Edit Text found in the login.xml 
	Button btnLogin;
    Button Btnregister;
    Button passreset;
    
    
    EditText inputUsername;
    EditText inputPassword;
    
    private TextView loginErrorMsg;
    
    /**
     * Called when the activity is first created.
     * JSON Response node names.
     */
    private static String KEY_SUCCESS = "success";
    private static String KEY_USERNAME = "uname";
    private static String KEY_FIRSTNAME = "fname";
    private static String KEY_LASTNAME = "lname";
    private static String KEY_EMAIL = "email";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //When the app first runs, it will be directed to activity_login.xml
        setContentView(R.layout.activity_login);

        //This gets the value of the Buttons, Edit Text and TextView
        //by the id initialized within the layout login.xml
        inputUsername = (EditText) findViewById(R.id.username);
        inputPassword = (EditText) findViewById(R.id.pword);     
        
        
        Btnregister = (Button) findViewById(R.id.registerbtn);
        btnLogin = (Button) findViewById(R.id.login);
        passreset = (Button) findViewById(R.id.passres); 
        
        
        loginErrorMsg = (TextView) findViewById(R.id.loginErrorMsg);

        
        
        
        //This initializes the action when a certain button it pressed
        //The Button Forgot Password is activated.
        passreset.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View view){
        		
        		//If the Forgot Password button is clicked then it will
        		//be redirected to the activity called PasswordReset.java
        		Intent myIntent = new Intent(view.getContext(), PasswordReset.class);
        		startActivityForResult(myIntent, 0);
        		finish();
        	}
        });
        
        
        
        
        //This initializes the action when a certain button it pressed
        //The Button Register is activated.
        Btnregister.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
            	
            	
            	
            	Log.d("Login","I am in Btnregister onclick");
            	
            	
            	
            	//If the Register button is clicked then it will
        		//be redirected to the activity called Register.java
                Intent myIntent = new Intent(view.getContext(), Register.class);
                startActivityForResult(myIntent, 0);
                
                
                Log.d("Login", "I am leaving Btnregister onclick");
                
                
                finish();
             }
        });

        /**
         * Login button click event
         * A Toast is set to alert when the Email and Password field is empty
         **/
        btnLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
            	//If both the Username and Password were inputted then redirect to function NetAsync
            	
            	
            	Log.d("Login","This is starting the login");
            	
            	
            	
                if (  ( !inputUsername.getText().toString().equals("")) && ( !inputPassword.getText().toString().equals("")) )
                {
                    NetAsync(view);

                }
                //If only the Username was inputted, then display an error message
                else if ( ( !inputUsername.getText().toString().equals("")) )
                {
                    Toast.makeText(getApplicationContext(),
                            "Password field is empty, please enter password", Toast.LENGTH_SHORT).show();
                }
                //If only the Password was inputted, then display an error message
                else if ( ( !inputPassword.getText().toString().equals("")) )
                {
                    Toast.makeText(getApplicationContext(),
                            "Username field is empty, please enter username", Toast.LENGTH_SHORT).show();
                }
                //Display error message if both the Username and Password are empty
                else
                {
                    Toast.makeText(getApplicationContext(),
                            "Username and Password field are empty ", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    /**
     * Async Task to check whether internet connection is working.
     **/
    //This class allows to perform background operations 
    //and publish results on the UI thread without having 
    //to manipulate threads and/or handlers
    private class NetCheck extends AsyncTask<String,String,Boolean>
    {
        private ProgressDialog nDialog;
       
        
        @Override
        //This is before it executes
        protected void onPreExecute(){
        	
        	
        	
        	Log.d("Login","THIS IS NETCHECK");
        	
        	
        	
            super.onPreExecute();
            nDialog = new ProgressDialog(Login.this);
            nDialog.setTitle("Checking Network");
            nDialog.setMessage("Loading..");
            nDialog.setIndeterminate(false);
            nDialog.setCancelable(true);
            nDialog.show();
        }
        
        
        
        
        
        /**
         * Gets current device state and checks for working internet connection by trying Google.
        **/
        //This is a thread that runs in the background
        @Override
        protected Boolean doInBackground(String... args)
        {

        	
        	
        	
        	Log.d("Login","THIS IS DOINBACKGROUND line213");
        	
        	
        	
        	
        	//The following snippet shows how to use the ConnectivityManager to query the active 
        	//network and determine if it has Internet connectivity.
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            
            if (netInfo != null && netInfo.isConnected()) {
                try {
                    URL url = new URL("http://www.google.com");
                    HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
                    urlc.setConnectTimeout(3000);
                    urlc.connect();
                    if (urlc.getResponseCode() == 200) {
                        return true;
                    }
                } 
                catch (MalformedURLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } 
                catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            return false;

        }
        //This is done afterward the doInBackground.
        //The concrete type bound to result is the type of 
        //the return value from doInBackground, and thus 
        //the type of the parameter to onPostExecute.
        @Override
        protected void onPostExecute(Boolean th){
            if(th == true){
                //If the return value from doInBackground is true
            	//then ProcessLogin.execute() is activated.
            	
            	
            	
            	Log.d("Login","THIS IS BEFORE GETTING INTO THE PROCESSLOGIN");
            	
            	
            	
            	
            	nDialog.dismiss();
                //new ProcessLogin().execute();
            }
            else{
            	//Otherwise an error message is sent
                nDialog.dismiss();
                loginErrorMsg.setText("Error in Network Connection");
            }
        }
    }

    /**
     * Async Task to get and send data to My Sql database through JSON respone.
     **/
    //If everything goes well in doInBackground then this function is called.
    private class ProcessLogin extends AsyncTask<String, String, JSONObject> {
    
    	private ProgressDialog pDialog;

        String username,password;

        @Override
        //Before executing, initialize variables
        protected void onPreExecute() {
            super.onPreExecute();

            
            Log.d("Login","THIS IS IN THE PROCESSLOGIN");

            
            username = inputUsername.getText().toString();
            password = inputPassword.getText().toString();
            
            pDialog = new ProgressDialog(Login.this);
            pDialog.setTitle("Contacting Servers");
            pDialog.setMessage("Logging in ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }
        
        //In the background access the Database using JSONObject
        @Override
        protected JSONObject doInBackground(String... args) {
        	
        	//Create an object to UserFunctions in order to access loginUser function
        	//which is located within UserFunctions.java
            UserFunctions userFunction = new UserFunctions();
            
            
            /* When calling loginUser, the username and password are sent as parameters.
             * The JSON response is sent back from loginUser() function.
             */
            
            
            
            Log.d("Login","THIS IS BEFORE DOING THE JSON LOGIN USER");
            
            
            
            
            JSONObject json = userFunction.loginUser(username, password);
            
            
            
            Log.d("Login","I ALREADY WENT TO THE PHP FILES");
            
            
            return json;
        }

        @Override
        protected void onPostExecute(JSONObject json) {
            try {
            	
            	
            	
            	Log.d("Login","THIS IS BACK FROM THE PHP FILES");
            	
            	
            	
               if (json.getString(KEY_SUCCESS) != null) {
            	   
            	   
            	   Log.d("Login","THIS IS WHERE I GOT THE ERROR?");
            	   
            	   
                    String res = json.getString(KEY_SUCCESS);

                    if(Integer.parseInt(res) == 1){
                        pDialog.setMessage("Loading User Space");
                        pDialog.setTitle("Getting Data");
                        //Creates an object to DatabaseHandler
                        
                        
                        
                        Log.d("Login","MAYBE I GOT IT HERE LINE361");
                        
                        
                        
                        DatabaseHandler db = new DatabaseHandler(getApplicationContext());
                        JSONObject json_user = json.getJSONObject("user");
                        
                        /**
                         * Clear all previous data in SQlite database.
                         **/
                        //Create an object to UserFunctions in order to access logoutUser function
                    	//which is located within UserFunctions.java
                        UserFunctions logout = new UserFunctions();
                        logout.logoutUser(getApplicationContext());
                        //This calls a function within DatabaseHandler.java, inorder to add a new User
                        db.addUser(json_user.getString(KEY_USERNAME),json_user.getString(KEY_FIRSTNAME),json_user.getString(KEY_LASTNAME),json_user.getString(KEY_EMAIL));
                       
                        /**
                        *If JSON array details are stored in SQlite it launches the User Panel.
                        **/
                        //After the login was verified, the app will go to activity called Main.java
                        //Which is the main page for the users account
                      
                        Intent upanel = new Intent(getApplicationContext(), Main.class);
                        upanel.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        pDialog.dismiss();
                        startActivity(upanel);
                        
                        /**
                         * Close Login Screen
                         **/
                        finish();
                    }
                    else{

                        pDialog.dismiss();
                        loginErrorMsg.setText("Incorrect username or password");
                    }
                }
            } 
            catch (JSONException e) {
                e.printStackTrace();
            }
       }
    }
    
    //This function is called when both the Username and Password are inputted
    public void NetAsync(View view){
    	//Creates and object of the class and called the function
        new NetCheck().execute();
    }
}