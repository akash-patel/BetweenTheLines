/*Written By: Alejandra Jurado & Janet Jewell
 * Tested By: Alejandra Jurado & Janet Jewell
 * Debugged By: Alejandra Jurado & Janet Jewell
 *
 * 
 * Register activity file will store the user 
 * details in the MySQL database and it is sent through JSON 
 * response. The username is unique in the user database and 
 * the email is checked whether it is valid or not. If the 
 * registration is success a email is sent to the users 
 * email for successful registration and user is redirected to 
 * Registered screen which shows the registration details.
 */
package com.example.betweenthelines;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.library.DatabaseHandler;
import com.example.library.UserFunctions;

public class Register extends ActionBarActivity {

	//Declaration of variables
	//For Button and the Edit Text found in the register.xml 
    EditText inputFirstName;
    EditText inputLastName;
    EditText inputUsername;
    EditText inputEmail;
    EditText inputPassword;
    EditText inputPasswordConfirm;
    
    
    Button btnRegister;
    private TextView registerErrorMsg;
 
	/**
	 *  Called when the activity is first created.
     *  JSON Response node names.
     *  
     *  
     *  
     *  private static String KEY_UID = "uid";
     *  private static String KEY_CREATED_AT = "created_at";
     **/
    
    
    private static String KEY_SUCCESS = "success";
    private static String KEY_FIRSTNAME = "fname";
    private static String KEY_LASTNAME = "lname";
    private static String KEY_USERNAME = "uname";
    private static String KEY_EMAIL = "email";
    private static String KEY_ERROR = "error";


    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState){
    	super.onCreate(savedInstanceState);
    	
    	//When the app first runs, it will be directed to register.xml
        setContentView(R.layout.register);

        
        
        
        Log.d("Register","I am entering register oncreate");
        
        
        
        
        /**
         * Defining all layout items
         **/
        //This gets the value of the Buttons by the id initialized
        //within the layout register.xml
        inputFirstName = (EditText) findViewById(R.id.fname);
        inputLastName = (EditText) findViewById(R.id.lname);
        inputUsername = (EditText) findViewById(R.id.uname);
        inputEmail = (EditText) findViewById(R.id.email);
        inputPassword = (EditText) findViewById(R.id.pword);  
        btnRegister = (Button) findViewById(R.id.register);        
        registerErrorMsg = (TextView) findViewById(R.id.register_error);
        inputPasswordConfirm = (EditText) findViewById(R.id.editTextConfirmPass);


        /**
         * Button which Switches back to the login screen on clicked
         **/
        Button login = (Button) findViewById(R.id.bktologin);
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
            	
            	//If the Back To Login button is clicked then it will
        		//be redirected to the activity called Login.java
                Intent myIntent = new Intent(view.getContext(), Login.class);
                startActivityForResult(myIntent, 0);
                finish();
            }
        });

        
        
        
        Log.d("Register", "Im still in register oncreate");
        
        
        
        
        /**
         * Register Button click event.
         * A Toast is set to alert when the fields are empty.
         * Another toast is set to alert Username must be 5 characters.
         **/
        btnRegister.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
            	
            	//If Username, Password, First Name, Last Name and Email were inputted then redirect to function NetAsync
                if (  ( !inputUsername.getText().toString().equals("")) && ( !inputPassword.getText().toString().equals("")) && ( !inputFirstName.getText().toString().equals("")) && ( !inputLastName.getText().toString().equals("")) && ( !inputEmail.getText().toString().equals("")) && ( !inputPasswordConfirm.getText().toString().equals("")) )
                {
                	//Checks to see if Username is greater than 4 characters in length
                    if ( inputUsername.getText().toString().length() > 4 ){
                    	//Checks to see if both passwords are equal
                    	if(!inputPassword.getText().toString().equals(inputPasswordConfirm.getText().toString()))
                    	{
                    		Toast.makeText(getApplicationContext(), 
                    				"Password does not match", Toast.LENGTH_LONG).show();
                    	}
                    	else
                    	{
                    		
                    		
                    		Log.d("Register","Now im leaving register oncreate");
                    		
                    		
                    		NetAsync(view);
                    	}
                    }
                    else
                    {
                    	//If its not greater than 4 characters, then an error message will show that it must be greater than 4 characters
                    	//****THIS MAY HAVE TO CHANGE****//
                        Toast.makeText(getApplicationContext(),
                                "Username should be minimum 5 characters", Toast.LENGTH_SHORT).show();
                    }
                }
                //If one or multiple fields are empty, an error message will display
                else
                {
                    Toast.makeText(getApplicationContext(),
                            "One or more fields are empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
    }
    
    /**
     * Async Task to check whether internet connection is working.
     **/
    //This class allows to perform background operations 
    //and publish results on the UI thread without having 
    //to manipulate threads and/or handlers
    private class NetCheck extends AsyncTask<String,String,Boolean>
    {
        private ProgressDialog nDialog;

        @Override
        //This is before it executes
        protected void onPreExecute(){
            super.onPreExecute();
            nDialog = new ProgressDialog(Register.this);
            nDialog.setMessage("Loading..");
            nDialog.setTitle("Checking Network");
            nDialog.setIndeterminate(false);
            nDialog.setCancelable(true);
            nDialog.show();
        }

        /**
         * Gets current device state and checks for working internet connection by trying Google.
        **/
        //This is a thread that runs in the background
        @Override
        protected Boolean doInBackground(String... args){

        	
        	
        	
        	
        	Log.d("Register","Now im in register NetCheck");
        	
        	
        	
        	
        	
        	//The following snippet shows how to use the ConnectivityManager to query the active 
        	//network and determine if it has Internet connectivity.
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            
            if (netInfo != null && netInfo.isConnected()) {
                try {
                    URL url = new URL("http://www.google.com");
                    HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
                    urlc.setConnectTimeout(3000);
                    urlc.connect();
                    if (urlc.getResponseCode() == 200) {
                        return true;
                    }
                } 
                catch (MalformedURLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } 
                catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            return false;
        }
        
        //This is done after the doInBackground.
        //The concrete type bound to result is the type of 
        //the return value from doInBackground, and thus 
        //the type of the parameter to onPostExecute.
        @Override
        protected void onPostExecute(Boolean th){
            if(th == true){
                nDialog.dismiss();
                //If the return value from doInBackground is true
            	//then ProcessRegister.execute() is activated.
                Log.d("Register","Now im leaving register NetCheck, entering ProcessRegister");
                new ProcessRegister().execute();
            }
            else{
                nDialog.dismiss();
                //Otherwise an error message is sent
                registerErrorMsg.setText("Error in Network Connection");
            }
        }
    }
	
    /**
     * Async Task to get and send data to My Sql database through JSON respone.
     **/
    //If everything goes well in doInBackground then this function is called.
    private class ProcessRegister extends AsyncTask<String, String, JSONObject> 
    {
        /**
    	 * Defining Process dialog
    	 **/
        private ProgressDialog pDialog;

        String email,password,fname,lname,uname;
        
        @Override
      //Before executing, initialize variables
        protected void onPreExecute() {
            super.onPreExecute();
            
            
            
            
            
            inputUsername = (EditText) findViewById(R.id.uname);
            inputPassword = (EditText) findViewById(R.id.pword);
            
            
            
            
            fname = inputFirstName.getText().toString();
            lname = inputLastName.getText().toString();
            email = inputEmail.getText().toString();
            uname= inputUsername.getText().toString();
            password = inputPassword.getText().toString();
            
            pDialog = new ProgressDialog(Register.this);
            pDialog.setTitle("Contacting Servers");
            pDialog.setMessage("Registering ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            
                 
        }

        
        //In the background access the Database using JSONObject
        @Override
        protected JSONObject doInBackground(String... args){
        	//Create an object to UserFunctions in order to access registerUser function
        	//which is located within UserFunctions.java
        	UserFunctions userFunction = new UserFunctions();
        	/* When calling registerUser, the username, password, email, first name
        	 * and last name are sent as parameters.
             * The JSON response is sent back from registerUser() function.
             */
        	
        	
        	
        	Log.d("Register","Now im doing JSON work entering UserFunction");
        	
        	
        	
        	JSONObject json = userFunction.registerUser(fname, lname, email, uname, password);
            return json;
        }
        
        
        
       @Override
        protected void onPostExecute(JSONObject json) {
    	   /**
    	    * Checks for success message.
    	    **/
    	   try {
                    if (json.getString(KEY_SUCCESS) != null) {
                        registerErrorMsg.setText("");
                        String res = json.getString(KEY_SUCCESS);

                        String red = json.getString(KEY_ERROR);

                        if(Integer.parseInt(res) == 1){
                        	
                        	
                            pDialog.setTitle("Getting Data");
                            pDialog.setMessage("Loading Info");
                            
                            //sends a message in the registerErrorMsg
                            registerErrorMsg.setText("Successfully Registered");
                            
                            //Creates an object to DatabaseHandler
                            DatabaseHandler db = new DatabaseHandler(getApplicationContext());
                            JSONObject json_user = json.getJSONObject("user");

                            /**
                             * Removes all the previous data in the SQlite database
                             **/
                            //Create an object to UserFunctions in order to access logoutUser function
                        	//which is located within UserFunctions.java
                            UserFunctions logout = new UserFunctions();
                            logout.logoutUser(getApplicationContext());
                          //This calls a function within DatabaseHandler.java, inorder to add a new User
                            
                            
                            db.addUser(json_user.getString(KEY_USERNAME),json_user.getString(KEY_FIRSTNAME),json_user.getString(KEY_LASTNAME),json_user.getString(KEY_EMAIL));
                            
                            
                            
                            
                            Log.d("Register","HI IM BACK FROM ADDUSER LINE379");
                            
                            
                            
                            
                            
                            /**
                             * Stores registered data in SQlite Database
                             * Launch Registered screen
                             **/
                            //After the registration is finished, the app will go to activity called Registered.java
                            //Which displays registration information
                            Intent registered = new Intent(getApplicationContext(), Registered.class);

                            /**
                             * Close all views before launching Registered screen
                            **/
                            registered.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            pDialog.dismiss();
                            startActivity(registered);
                            finish();
                        }

                        else if (Integer.parseInt(red) == 2){
                            pDialog.dismiss();
                            registerErrorMsg.setText("User already exists");
                        }
                        else if (Integer.parseInt(red) == 3){
                            pDialog.dismiss();
                            registerErrorMsg.setText("Invalid Email id");
                        }

                    }
                    else{
                        pDialog.dismiss();
                        registerErrorMsg.setText("Error occured in registration");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
    }
    
    //This function is called when all the fields are inputted
    public void NetAsync(View view){
    	new NetCheck().execute();
    }    
}



